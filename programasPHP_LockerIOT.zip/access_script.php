<script>

var totalGroups=groups.length;
var totalLockers=lockers.length;
var groupSelected=[];
var lockerSelected=[];


window.onload = function() {
	
	if(totalGroups>1)
		selecGroups();
	else{
		groupSelected=groups[0];
		selecLocker();
	}
		

};


function selecGroups(){
	<?php
	$txtEspanol="<p>Por favor, seleccione un grupo de taquillas</p>";
	$txtAleman="<p>Bitte w&auml;hlen Sie eine Gruppe von Schlie&szlig;f&auml;chern</p>";
	$txtIngles="<p>Please, select a Group of Lockers</p>";
	$txt=espaleing($txtEspanol,$txtAleman,$txtIngles);   
	?>
	document.getElementById("gestion").innerHTML="<?php  echo $txt; ?>";
	for (var i=0; i<totalGroups ; i++) {
      putGroup(i);
    }
	
}

function putGroup(i){
	document.getElementById("gestion").innerHTML+="<div class='boton' onclick=asignaGrupo("+ i +")>"+ groups[i][2]+ " | " + groups[i][3] + " | "  + groups[i][4] + " | "  + groups[i][5] +"</div>";
}

function asignaGrupo(i){
	groupSelected=groups[i];
	selecLocker();
}

function selecLocker(){
	<?php
	$txtEspanol="Grupo de taquillas:";
	$txtAleman="Gruppe Schlie&szlig;f&auml;cher:";
	$txtIngles="Lockers Group:";
	$txt1=espaleing($txtEspanol,$txtAleman,$txtIngles);  

    $txtEspanol="Tiene permiso para usar ";
	$txtAleman="Sie d&uuml;rfen ";
	$txtIngles="You are allowed to use ";
	$txt2=espaleing($txtEspanol,$txtAleman,$txtIngles); 	
	
	$txtEspanol=" taquillas</p>";
	$txtAleman="Schlie&szlig;f&auml;cher benutzen";
	$txtIngles="Lockers.";
	$txt3=espaleing($txtEspanol,$txtAleman,$txtIngles); 
	
	$txtEspanol="<p id='opciones'>Por favor, selecione una taquilla <span class='boton2t'>libre</span></p>";
	$txtAleman="<p id='opciones'>Bitte w&auml;hlen Sie ein <span class='boton2t'>nicht besetztes</span> Schlie&szlig;fach </p>";
	$txtIngles="<p id='opciones'>Please, select a <span class='boton2t'>Free</span> Locker</p>";
	$txt4=espaleing($txtEspanol,$txtAleman,$txtIngles);
	
	$txtEspanol="<p id='opciones'><span class='icon-sad'></span> Lo sentimos!, en este momento todas las taquillas est&aacute;n ocupadas.</p>";
	$txtAleman="<p id='opciones'><span class='icon-sad'></span> Entschuldigung! alle Schlie&szlig;f&auml;cher sind derzeit belegt. </p>";
	$txtIngles="<p id='opciones'><span class='icon-sad'></span> Sorry! all lockers are currently occupied.</p>";
	$txt5=espaleing($txtEspanol,$txtAleman,$txtIngles);
	
	?>
	if(lockerSelected.length>0)
		return;
	document.getElementById("gestion").innerHTML="<p><?php  echo $txt1; ?> "+ groupSelected[2]+ " | " + groupSelected[3] + " | "  + groupSelected[4] + " | "  + groupSelected[5] +"</p>";
	if(groupSelected[6]>1)
		document.getElementById("gestion").innerHTML+="<p><?php  echo $txt2; ?> "+groupSelected[6]+" <?php  echo $txt3; ?></p>";
	
	var lockersInGroup=0;
	var ocupadasOtros=0;
	
	var asignadas=0;
	for (var i=0; i<totalLockers ; i++) {
		if(lockers[i][1]==groupSelected[1]){
		   lockersInGroup++;
		    if(lockers[i][4]==1)
				ocupadasOtros++;
		}	
    }	
	
	if (ocupadasOtros<lockersInGroup){
		document.getElementById("gestion").innerHTML+="<?php  echo $txt4; ?>";
	}else{
		document.getElementById("gestion").innerHTML+="<?php  echo $txt5; ?>";
	}
	
	
	<?php
	$txtEspanol="o seleccione la taquilla <span class='boton4t'>ya asignada</span> que desee usar. ";
	$txtAleman="oder w&auml;hlen Sie das <span class='boton4t'>zugewiesene Schlie&szlig;fach</span>, das Sie verwenden m&ouml;chten.";
	$txtIngles="or select wich <span class='boton4t'>assigned</span> Locker you want to use.";
	$txt1=espaleing($txtEspanol,$txtAleman,$txtIngles);  
	
	$txtEspanol="Por favor, seleccione la taquilla <span class='boton4t'>ya asignada</span> que desee usar. ";
	$txtAleman="Bitte, w&auml;hlen Sie das <span class='boton4t'>zugewiesene Schlie&szlig;fach</span>, das Sie verwenden m&ouml;chten.";
	$txtIngles="Please,  select wich <span class='boton4t'>assigned</span> Locker you want to use.";
	$txt2=espaleing($txtEspanol,$txtAleman,$txtIngles);  

	?>
	
	if (asignadas>0 && groupSelected[6]>asignadas){
		document.getElementById("opciones").innerHTML+=" <?php  echo $txt1; ?>";
	}
	if (asignadas>=groupSelected[6]){
		$('.boton2').addClass('boton3');
		$('.boton3').removeClass('boton2');
		$(".boton3").prop("onclick", null).off("click");
		document.getElementById("opciones").innerHTML="<?php  echo $txt2; ?>";
	}
	
	for (var i=0; i<totalLockers ; i++) {
		if(lockers[i][1]==groupSelected[1]){	   
           putLocker(i);
			if(lockers[i][4]==2){
				asignadas++;
				if(asignadas==1 && groupSelected[6]==1){
					lockerSelected=lockers[i];
					gestionLocker();
					return;
				}
			}
		}	
    }
}

function putLocker(i){
	<?php
	$txtEspanol="Taquilla";
	$txtAleman="Schlie&szlig;fach";
	$txtIngles="Locker";
	$txt=espaleing($txtEspanol,$txtAleman,$txtIngles);  
	?>
	
	if(lockers[i][4]==0)
	 document.getElementById("gestion").innerHTML+="<div class='boton2' onclick='asignaLocker("+ i +")'><?php  echo $txt; ?> Nr. :"+ lockers[i][3]+ "</div>";
    else{
		if(lockers[i][4]==2){
			document.getElementById("gestion").innerHTML+="<div class='boton4' onclick='asignaLocker("+ i +")'><?php  echo $txt; ?> Nr. :"+ lockers[i][3]+ "</div>";
		}else{
			document.getElementById("gestion").innerHTML+="<div class='boton3' onclick=''><?php  echo $txt; ?> Nr. :"+ lockers[i][3]+ "</div>";
		}
			
	}
	 
	 
}

function asignaLocker(i){
	lockerSelected=lockers[i];
	gestionLocker();
}

function gestionLocker(){
	<?php
	$txtEspanol="Grupo de Taquillas:";
	$txtAleman="Gruppe Schlie&szlig;f&auml;cher: ";
	$txtIngles="Lockers Group:";
	$txt1=espaleing($txtEspanol,$txtAleman,$txtIngles);  
	
	$txtEspanol="Acceso a Taquilla Nr.:";
	$txtAleman="Zugang zum Schlie&szlig;fach Nr.: ";
	$txtIngles="Access to Locker Nr.:";
	$txt2=espaleing($txtEspanol,$txtAleman,$txtIngles); 
	
	$txtEspanol="Por favor, espere... cargando informaci&oacute;n de la Taquilla";
	$txtAleman="Bitte warten... Laden von Schlie&szlig;fach Informationen";
	$txtIngles="Please wait... loading Locker information";
	$txt3=espaleing($txtEspanol,$txtAleman,$txtIngles); 
	
	?>
	if(lockerSelected.length==0)
		return;
	document.getElementById("gestion").innerHTML="<p><?php  echo $txt1; ?> "+groupSelected[2]+ " | " + groupSelected[3] + " | "  + groupSelected[4] + " | "  + groupSelected[5] +"</p>";
	document.getElementById("gestion").innerHTML+="<p><?php  echo $txt2; ?>" +  lockerSelected [3] + "</p>";
	document.getElementById("gestion").innerHTML+="<div id='infolocker'><p class='avisoespera'> <span class='icon-info'></span>  <?php  echo $txt3; ?> </p></div>";
	
	$.get("infolocker.php?id="+lockerSelected[2] , function(resp) {
					document.getElementById("infolocker").innerHTML=resp;
				});
}

function openLocker(){
	<?php
	$txtEspanol="Por favor, espere... enviando orden de apertura a la Taquilla";
	$txtAleman="Bitte warten... Er&ouml;ffnungsauftrag an Schlie&szlig;fach senden ";
	$txtIngles="Please wait... sending opening order to Locker ";
	$txt=espaleing($txtEspanol,$txtAleman,$txtIngles);  
	?>

	if(lockerSelected.length==0)
		return;
	
	document.getElementById("infolocker").innerHTML="<p class='avisoespera'> <span class='icon-info'></span>  <?php  echo $txt; ?></p>";
	$.get("infolocker.php?open=1&id="+lockerSelected[2] , function(resp) {
					document.getElementById("infolocker").innerHTML=resp;
				});
	
}

function releaseLocker(){
	<?php
	$txtEspanol="Por favor, espere... enviando orden de liberaci&oacute;n de taquilla.";
	$txtAleman="Bitte warten... Er&ouml;ffnungsauftrag an Schlie&szlig;fach senden ";
	$txtIngles="Please wait... LOCKER FREIGEBEN Bestellung senden ";
	$txt=espaleing($txtEspanol,$txtAleman,$txtIngles);  
	?>

	if(lockerSelected.length==0)
		return;
	
	document.getElementById("infolocker").innerHTML="<p class='avisoespera'> <span class='icon-info'></span>  <?php  echo $txt; ?></p>";
	$.get("infolocker.php?free=1&id="+lockerSelected[2] , function(resp) {
					document.getElementById("infolocker").innerHTML=resp;
				});
	
}

function setMinsToAlarm(){
  document.getElementById("txtrangomins").innerHTML = document.getElementById("rangomins").value;
}

function timeToAlarmLocker(){
	
	<?php
	$txtEspanol="Por favor, espere... enviando cambio del tiempo de apertura para envio de email de alarma.";
	$txtAleman="Bitte warten... &Auml;nderung der &Ouml;ffnungszeit f&uuml;r E-mail Alarm senden.";
	$txtIngles="Please wait... sending change of opening time for email alarm. ";
	$txt=espaleing($txtEspanol,$txtAleman,$txtIngles);  
	?>
	
	if(lockerSelected.length==0)
		return;
	var mins = document.getElementById("txtrangomins").innerHTML;
	document.getElementById("infolocker").innerHTML="<p class='avisoespera'> <span class='icon-info'></span><?php  echo $txt; ?></p>";
	$.get("infolocker.php?ma="+mins+"&id="+lockerSelected[2] , function(resp) {
					document.getElementById("infolocker").innerHTML=resp;
				});


}


</script>


	