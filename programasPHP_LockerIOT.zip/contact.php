<?php
session_start();
require('general_func.php');
ponIdioma();
// Variables para datos de cabecera
$_SESSION['titulopagina']="Locker IOT By Oscar Vicario | Kontakt | Contacto";
$_SESSION['description']="Locker IOT By Oscar Vicario";
$_SESSION['keywords']="";
 
?>

	<?php  	include ('cabecera.php');  ?>
	
	<?php   include ('menunavegacion.php');  ?>
	
 	
	<section>
	
	<article><span class='no_selection'>
	
	

<h1 class="siloprimero"><br>&Oacute;scar Vicario Villa</h1>
<p  class="fotocvv" >
  <img  src="images/oscar.jpg"  alt="Oscar Vicario Villa"/>
</p>

	 <h1><br> <?php  	echo espaleing("Sobre mi :","Über mich :","About me:");  ?> </h1><br> 


<h1> <?php  	echo espaleing("Contacto ","Kontakt", "Contact");  ?> :</h1>

<ul class="contactos">
<li class="indent0"><a href="mailto:oscarvicario@lockeriot.com"><span class="icon-envelop"></span> oscarvicario@lockeriot.com</a></li>
<li class="indent0"><a href='https://de.linkedin.com/in/oscar-vicario-villa-75202a1b8' target='_blank'><span class="icon-linkedin"></span> https://de.linkedin.com/in/oscar-vicario-villa-75202a1b8</a></li>

<li class="indent0"> </li>
<li class="indent0"> </li>

</ul>

<br>
<br>
<br>

	</span>
	</article>
	
	

	
	</section>
	
	
	
	<?php  include ('piepagina.php');  ?>
	
	</body> 
	
</html>