<?php
session_start();
require('general_func.php');
ponIdioma();

// Variables para datos de cabecera
$_SESSION['titulopagina']="Solicitud enviada | Locker IOT ";
$_SESSION['description']="Solicitud enviada | Locker IOT";
$_SESSION['keywords']="Locker IOT";


// ponemos cabeceras y menu
 	
	
	  include ('cabecera.php'); 
	  include ('menunavegacion.php'); 
	
 	
	echo "<section>";
	
	echo "<article class='no_selection'>";
	
// auxiliar para recibir los post
/*	
foreach($_POST as $nombre_campo => $valor){ 
    $asignacion = "\$" . $nombre_campo . "='" . $valor . "';"; 
    echo $asignacion."<br>"; 
 }
*/

// Si llega aqui es porque el alumno se ha registrado
if(isset($_SESSION['nuevoemail']) and strlen(trim($_SESSION['nuevoemail']))>0 )
{
  
    // generamos clave provisional 
	
	 $_SESSION['claveprovis']=mt_rand(15978166,51382971);
     	 
	 
     $query = "INSERT INTO users ( fullname, email, telephone, clave  ) 
	 VALUES ('".addslashes($_SESSION['nuevonombre']).
	 "', '".$_SESSION['nuevoemail'].
	 "', '".addslashes($_SESSION['nuevotelefono']).
	 "', SHA1('".$_SESSION['claveprovis']. "')  )";
	 
	$result = conecta($query);
	
	
    $query = "select * from users where email='".$_SESSION['nuevoemail']."'" ;
	$result = conecta($query);
	
	if (mysqli_num_rows($result) >0 )
	{  // el alta de ha dado correctamente
	
		$fila = mysqli_fetch_assoc($result);
		$clave_get=$fila['clave'];
		
		$iduser=$fila['iduser'];  // con esto y con $_SESSION['nuevoidgroup'] damos de alta también en el groupsusers 
		$query = "INSERT INTO groupsusers ( idgroup, iduser  ) VALUES (".$_SESSION['nuevoidgroup'].", ".$iduser." )";
		$result = conecta($query);


	  // enviamos email al nuevo usuario
	  // echo $claveprovis; // solo para pruebas
	         // enviamos email
		$txtEspanol="Locker IOT [Registro]";
		$txtAleman="Locker IOT [Registrierung]";
		$txtIngles="Locker IOT [User registration]";
	
		$asunto = "Locker IOT [".espaleing($txtEspanol,$txtAleman,$txtIngles)."]";
			 
        
		$acceso="<a href='https://www.lockeriot.com/access.php?cl=". $clave_get."&us=".$_SESSION['nuevoemail']."'>https://www.lockeriot.com</a>";
		
        $txtEspanol = "
        <html>
         <head>
           <title>".$asunto."</title>
         </head>
        <body>
          
          <p>Atendiendo a su solicitud le remitimos sus claves de acceso a nuestra web  
		  <strong>www.lockeriot.com</strong> :</p>
          </br>
			<p>e-mail: " .$_SESSION['nuevoemail']."
           </br>
          <p>Clave de acceso: " .$_SESSION['claveprovis'].
          "
           </p>  </br>
		   <p>Tras su acceso podr&aacute; realizar el cambio de su clave por una nueva m&aacute;s f&aacute;cil de recordar para usted.</p>
          <p> Puede acceder directamente desde este enlace: </p>
           </br>  <p>
           ".$acceso."
           </p>
           </br>
		   <p>o dirigi&eacute;ndose en cualquier otro momento a <strong>www.lockeriot.com</strong></p>
		   <br>
		   <p>Gracias </p>
		   <br>

		   <br>
		   <p>Atentamente,</p>
           <br>
		   <p>Oscar Vicario<br>
		   Locker IOT<br>
		   </p>
           
       </body>
       </html>
       ";
	   
	   $txtAleman = "
        <html>
         <head>
           <title>".$asunto."</title>
         </head>
        <body>
          
          <p>Als Reaktion auf eine Anfrage zur Wiederherstellung von Zugangscodes,
		  diese in Ihrem Registrierungsformular angegebene E-Mail wurde gesendet. </p>
          
		   <p>Sie k&ouml;nnen direkt zugreifen, indem Sie auf den folgenden Link klicken:</p>
		   <p>
           ".$acceso."
           </p>
		   <p>Nach der Anmeldung k&ouml;nnen Sie Ihr Passwort durch ein neues, das Sie sich leichter merken k&ouml;nnen, &auml;ndern.</p>
		   <br>
		   <p>oder adressieren zu jeder anderen Zeit an <strong>www.lockeriot.com</strong></p>
		   <br>
		   <p>Vielen Dank.</p>
		   <br>

			<p><p>
		   <br>
		   
           <br>
		   <p>&Oacute;scar Vicario Villa<br>
		   Locker IOT</p>
       </body>
       </html>
       ";
	   
	   $txtIngles = "
        <html>
         <head>
           <title>".$asunto."</title>
         </head>
        <body>
          
          <p>In response to a request for the recovery of access codes,
		  this email provided in your registration form has been sent. </p>
          
		   <p>You can access directly by clicking on the following link:</p>
		   <p>
           ".$acceso."
           </p>
		   <p>After logging in, you can change your password for a new one that is easier for you to remember.</p>
		   <br>
		   <p>or addressing at any other time to <strong>www.lockeriot.com</strong></p>
		   <br>
		   <p>Thanks.</p>
		   <br>

			<p><p>
		   <br>
		   
           <br>
		   <p>&Oacute;scar Vicario Villa<br>
		   Locker IOT</p>
       </body>
       </html>
       ";
	   
	   $cuerpo= espaleing($txtEspanol,$txtAleman,$txtIngles);
	   
      //para el envío en formato HTML
      
        $headers = "MIME-Version: 1.0\n";
        $headers .= "Content-type: text/html; charset=iso-8859-1\n";
        
        $headers .= "From: lockeriot.com<info@lockeriot.com>\n";

	   
	   //direcciones que recibirán copia oculta 
		$headers .= "Bcc: info@lockeriot.com, marcovicario@farmatural.com\n"; 
        
      if(mail($_SESSION['nuevoemail'],$asunto,$cuerpo,$headers))
       {
	   // mail ok
	   }
	   else
	   {
	    $errorenviomail=1;
	   }
  

	$txtEspanol='<p>Su solicitud de registro ha sido completada.<br>
	        Muchas gracias por su interés.<br>
En breve plazo recibirá un correo electrónico con sus claves de acceso.<br>
Por favor, revise su correo y asegúrese de identificarlo como correo seguro.<br>
</p>';
	$txtAleman='<p>Ihre Registrierungsanfrage wurde abgeschlossen.<br>
	        Vielen Dank für Ihr Interesse.<br>
Sie werden in Kürze eine E-Mail mit Ihren Zugangsdaten erhalten.<br>
Bitte überprüfen Sie Ihre E-Mail und stellen Sie sicher, dass es sich um eine sichere E-Mail handelt.<br>
</p>';
	$txtIngles='<p>Your registration request has been completed.<br>
	        Thank you for your interest.<br>
You will receive an email with your access codes shortly.<br>
Please check your email and be sure to identify it as a secure email.<br>
</p>';
	echo espaleing($txtEspanol,$txtAleman,$txtIngles); 				
					
 
	

		

	// Enviamos email de aviso a la Central
	$cuerpo= "
        <html>
         <head>
           <title>Nueva Solicitud de Registro.</title>
         </head>
        <body>
		  <p>nombre: ".htmlspecialchars($_SESSION['nuevonombre'])."</p>
		  <p>email: ".htmlspecialchars($_SESSION['nuevoemail'])."</p>
		  <p>telefono: ".htmlspecialchars($_SESSION['nuevotelefono'])."</p>
		  
		  <p>Ha solicitado el registro en <strong>Locker IOT</strong>.</p>
		  
		  <p>IP: ".dameIPusuario()."</p>
          
           

        
       </body>
       </html>
       ";
      //para el envío en formato HTML
        $asunto="Solicitud Registro en lockeriot.com :  ( ".$_SESSION['nuevonombre']." ) ";
		
        $headers = "MIME-Version: 1.0\n";
        $headers .= "Content-type: text/html; charset=iso-8859-1\n";
        
        $headers .= "From: Locker IOT<info@lockeriot.com>\n";
        //dirección de respuesta, si queremos que sea distinta que la del remitente
       //$headers .= "Reply-To: info@iberochino.com\n";

       //ruta del mensaje desde origen a destino
       //$headers .= "Return-path: info@iberochino.com\n";
        
      if(mail('info@lockeriot.com',$asunto,$cuerpo,$headers))
       {
      
       }
      else  // falla la acción de enviar el e-mail
       {
        $errorenmail=1;
       }
	 
	 
	}  // fin proceso alta correctamente
	
	  // Para usuarios nuevos, destruimos sesión y creamos sesion nueva. 
	  // Necesario si se han de dar de alta varios usuarios en la misma sesión.
	  // se destruye la sesion
		session_destroy();
	  // se reinicia una sesion
		session_start();
	  // creamos un nuevo id sesion. 
		session_regenerate_id();
	
	
	// echo '<p><a href="index.php">acceso al área de usuarios.</a></p>';
	}
	else
	{

	}

	?>
	
	</article>

	</section>
	
	
	
	<?php  include ('piepagina.php');	?>
	
	</body> 
	
</html>