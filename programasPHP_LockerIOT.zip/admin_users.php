<?php
session_start();
require('general_func.php');
ponIdioma();
// Variables para datos de cabecera
$_SESSION['titulopagina']="Locker IOT Administration Menu";
$_SESSION['description']="Locker Administration Menu ";
$_SESSION['keywords']="Locker IOT";



// ponemos cabeceras y menu
 	
	
	  include ('cabecera.php'); 
	  include ('menunavegacion.php'); 
	
 	
	echo "<section>";
	
	echo "<article><span class=''>";



// en funcion de resultados se compone la página
if(isset($_SESSION['groupsadmin']) and $_SESSION['groupsadmin']>=1 )
{

if(isset($_GET['lockergroup']) and intval($_GET['lockergroup'])==1){
	// si hay orden de elminar una taquilla de un usuario, lo hacemos lo primero
	if(isset($_GET['remove']) and intval($_GET['remove'])>0){
		$query = "update lockers set iduser=0 , minsopentoalarm=5 where idlocker=".intval($_GET['remove']). " and idgroup=".intval($_GET['lockergroup']);
		$result = conecta($query);
		
	}
	
	// si hay orden de actualizar datos de usuaruo (o eliminar) lo hacemos antes de continuar
	if(isset($_GET['update']) and intval($_GET['update'])>0 and intval($_GET['allowlockers'])<100){
		if(isset($_GET['allowlockers']) and intval($_GET['allowlockers'])>0){
			$query = "update groupsusers set numlockersallowed=".intval($_GET['allowlockers']). "  where iduser=".intval($_GET['update']). " and idgroup=".intval($_GET['lockergroup']);
			$result = conecta($query);
		}else{
			if(isset($_GET['allowlockers']) and intval($_GET['allowlockers'])==0){
			// si el valor de allowlockers es 0, eliminamos cualquier asignación de taquillas al usuario  y tabmién lo eliminamos del grupo 
			$query = "update lockers set iduser=0 , minsopentoalarm=5 where iduser=".intval($_GET['update']). " and idgroup=".intval($_GET['lockergroup']);
			$result = conecta($query);
			// primero ponemos a 0 las taquillas permitidas
			$query = "update groupsusers set numlockersallowed=".intval($_GET['allowlockers']). "  where iduser=".intval($_GET['update']). " and idgroup=".intval($_GET['lockergroup']);
			$result = conecta($query);
			// luego borramos el enlace a cualquier taquilla , si no es el propio administrador
			if ($_SESSION['iduser'] != intval($_GET['update']) ){
				$query = "delete from groupsusers  where iduser=".intval($_GET['update']);
				$result = conecta($query);
				
				// por ultimo eliminamos el usuario a todos los efectos
				$query = "delete from users where iduser=".intval($_GET['update']);
				$result = conecta($query);
				
			}
			
			}
		}
		
	}
	
	if (isset($_GET['update']) and $_SESSION['iduser'] != intval($_GET['update']) ){
		// si hay actualización de usuario ADMIN se realiza salvo que sea el propio usuario (evita autoeclusión, incluso por modificacion de url)
		if(isset($_GET['update']) and isset($_GET['allowlockers']) and intval($_GET['allowlockers'])==100){
			// se establece nuevo admin
			$query = "update users set groupsadmin=1  where iduser=".intval($_GET['update']);
			$result = conecta($query);
		}
		
		if(isset($_GET['update']) and isset($_GET['allowlockers']) and intval($_GET['allowlockers'])==200){
			// se establece nuevo admin
			$query = "update users set groupsadmin=0  where iduser=".intval($_GET['update']);
			$result = conecta($query);
		}
	}
	
	// pantalla para Gestionar los usuarios
	
	
	$query = "select * from groups where idgroup=".intval($_GET['lockergroup']);
	$result = conecta($query);
	
	if (mysqli_num_rows($result) >0 ){ 
	  $resultado=mysqli_fetch_array($result);
	  
	  
	  echo "<p>".espaleing("Usuarios del Taquillero en :","USERS in der Gruppe Schließfächer:","USERS in Lockers Group:").$resultado['address']." | ".$resultado['address2']." | ".$resultado['place']." | ".$resultado['country']." </p>";
	 
	}
	
	$query = "select * from groupsusers,users where groupsusers.idgroup=".intval($_GET['lockergroup'])."  and groupsusers.iduser=users.iduser order by fullname";
	$result = conecta($query);
	//echo $query;
	echo '
<style>
	table {
   width: 80%;
   border: 1px solid #000;
   border-collapse: collapse;
   cellpadding:0;
   cellspacing:0;
   
}
th, td {
   width: 15%;
   text-align: left;
   vertical-align: top;
   border: 1px solid #000;
   border-collapse: collapse;
   padding: 0.3em;
}
</style>
';
	// ponemos formulario para mantenimento y  cabecera de tabla
	echo '<form name="form1" action="admin_users.php?lockergroup='.$_GET['lockergroup'].'" method="post">';

	echo "<table bgcolor='f8f8f8'>";
	echo "<tr>";
	echo "<td align='center' ><strong>User Name </strong></td>";
	echo "<td align='center'><strong>Telephone</strong></td>";
	echo "<td align='center' ><strong>email</strong></td>";
	echo "<td align='center' ><strong>Lockers in use</strong></td>";
	echo "<td align='center' ><strong>Lockers<br>Allowed</strong></td>";
	
	echo "<td align='center'><strong>Last Access</strong></td>";
	echo "</tr>" ;
	
	for ($i=0;$i<mysqli_num_rows($result); $i++)
               {
                $usuario[$i]=mysqli_fetch_array($result);
				echo "<tr>";
				echo "<td width='10%'>".$usuario[$i]['fullname'];
				 if($usuario[$i]['groupsadmin']>0){
					echo "<span class='rojo'> [Admin.]</span>"; 
				 }
					 
				 
				echo "</td>";
				echo "<td>".$usuario[$i]['telephone']."</td>";
				echo "<td>".$usuario[$i]['email']."</td>";
				
				echo "<td>";
				  // buscamos las taquillas que tiene actualmente en uso y damos la opción de desvincularlas al administrador
				  $query2 = "select * from lockers where idgroup=".intval($_GET['lockergroup'])."  and iduser=".$usuario[$i]['iduser']." order by numingroup";
				  $result2 = conecta($query2);
				  for ($j=0;$j<mysqli_num_rows($result2); $j++)
					   {
						$taquilla[$j]=mysqli_fetch_array($result2);
						echo "Num:".$taquilla[$j]['numingroup'];
						echo ' <input type="checkbox" id="remove'.$taquilla[$j]['idlocker'].'" onclick=muestraBotonRemove('.$taquilla[$j]['idlocker'].')>';
						echo " <div id='botonRemove".$taquilla[$j]['idlocker']."' ></div>";
					   }
				  
				echo "</td>";
				echo "<td>";
				  // mostramos el numero de taquillas que puede usar y damos opción a cambiarlo  o a eliminar el usuario
				  echo "<select name='allow".$usuario[$i]['iduser']."' id='allow".$usuario[$i]['iduser']."' onchange='muestraBotonUpdate(".$usuario[$i]['iduser'].")'>";
				 
				 if($usuario[$i]['iduser']!=$_SESSION['iduser']){
				  echo "<option value='0'>0 (remove user)</option>";
				 }
				 
				  echo "<option  value='1'";
				    if( $usuario[$i]['numlockersallowed'] == 1 )
						echo " selected ";
				  echo " >1</option>";
				  echo "<option  value='2'";
				    if( $usuario[$i]['numlockersallowed'] == 2 )
						echo " selected ";
				  echo " >2</option>";
				  echo "<option  value='3'";
				    if( $usuario[$i]['numlockersallowed'] == 3 )
						echo " selected ";
				  echo " >3</option>";
				 echo "<option  value='4'";
				    if( $usuario[$i]['numlockersallowed'] == 4 )
						echo " selected ";
				  echo " >4</option>";
				  echo "<option  value='5'";
				    if( $usuario[$i]['numlockersallowed'] == 5 )
						echo " selected ";
				  echo " >5</option>";
				  
				  
				  if($usuario[$i]['groupsadmin']<1){
					  echo "<option  value='100'>Set ADMIN.</option>";
				  }else{ 
					  if($usuario[$i]['groupsadmin']>0 and $usuario[$i]['iduser']!=$_SESSION['iduser']){
						echo "<option  value='200'>No ADMIN.</option>";
						}
				  }
				  
				  echo "</select>";
				  
				  echo " <div id='botonUpdate".$usuario[$i]['iduser']."' ></div>";
				echo "</td>";
				echo "<td>".$usuario[$i]['lastaccess']."</td>";
				

				echo "</tr>";
               }
			   
	echo "</table>";		   
	echo '</form>';
}	


	


}
?>	 

	
	 
	</span>
	</article>

	</section>
	
	
	
	<?php  include ('piepagina.php');	?>
	<script>
	 function muestraBotonRemove(idboton){
		 if(document.getElementById("remove" + idboton).checked ){
			document.getElementById("botonRemove" + idboton).innerHTML="<a href='admin_users.php?lockergroup=1&remove=" + idboton +"' class='login'> <?php  echo espaleing('Eliminar','entfernen','Remove')	?> </a>"; 
		 }else{
			document.getElementById("botonRemove" + idboton).innerHTML="";  
		 }
	 }
	
	 function muestraBotonUpdate(idboton){
		var allowlockers = document.getElementById("allow" + idboton).value;
		
		document.getElementById("botonUpdate" + idboton).innerHTML="<a href='admin_users.php?lockergroup=1&update=" + idboton + "&allowlockers=" + allowlockers + "' class='login'> <?php  echo espaleing('Cambiar','Update','Update')	?> </a>"; 
		 
	 }
	</script>
	
	</body> 
	
</html>