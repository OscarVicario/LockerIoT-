<?php
session_start();
require('general_func.php');
ponIdioma();

		$txtEspanol="Recuperar claves acceso";
		$txtAleman="Passwort wiederherstellen";
		$txtIngles="recover password";
	

// Variables para datos de cabecera
$_SESSION['titulopagina']= espaleing($txtEspanol,$txtAleman,$txtIngles). " | Locker IOT";
$_SESSION['description']=" ";
$_SESSION['keywords']="Locker IOT";

?>

	<?php  	include ('cabecera.php');  ?>
	
	<?php   include ('menunavegacion.php');  ?>
	
 	
	<section>
	
	<article>
	
	 
<?php

  echo "<br/>";

$mostrarformulariopeticion='s';
$nombredelalumno="";


if(isset($_POST['emailsolicitante']) and $_POST['emailsolicitante']<>"")
{
	
// 12-1-2015  guardamos dato en base datos recuerdaemail
   $queryNuevoemail = "INSERT INTO recuerdaemail ( emailre, ipre ) 
	 VALUES ('".$_POST['emailsolicitante']. "', '".dameIPusuario()."' )";

     $resultNuevoemail = conecta($queryNuevoemail);


// 1)Verificamos si es una dirección de e-mail correcta.
   if(comprobar_email($_POST['emailsolicitante'])){
	  
   }else{
	   $_POST['emailsolicitante']="error@email.error"; 
   }

// 2)Si es una direccion email correcta, buscamos en la base de datos de alumnos asociados a cursos
   $query = "select * from users where email='".$_POST['emailsolicitante']."' ";
   $result = conecta($query);
   
   

  if (mysqli_num_rows($result) >0 )
     // Si se ha encontrado el email, se toma el primero (normalmente solo hay uno)
     {
       $fila=mysqli_fetch_array($result);
       // 3)Si encontramos el alumno, mostramos un mensaje de bienvenida con su nombre, enviamos email y le informamos de que se ha enviado el e-mail
			
	   
        $mostrarformulariopeticion='n';
		
		$tipoAlumno="Normal";
		
		$txtEspanol="Recuperar claves acceso";
		$txtAleman="Passwort wiederherstellen";
		$txtIngles="recover password";
	
		$asunto = "Locker IOT [".espaleing($txtEspanol,$txtAleman,$txtIngles)."]";
		$accesoa="lockeriot.com ";
		$usuario= $_POST['emailsolicitante'];
		
		
		
		$clave_get=$fila['clave'];
			
		 
		$acceso="<a href='https://www.lockeriot.com/access.php?cl=". $clave_get."&us=".$_POST['emailsolicitante']."'>https://www.lockeriot.com</a>";
		
		$txtEspanol="Por favor, revise su correo";
		$txtAleman="Bitte &uuml;berpr&uuml;fen Sie Ihre E-Mail";
		$txtIngles="Please check your email";
		
	echo "<h1>".espaleing($txtEspanol,$txtAleman,$txtIngles)."</h1>";

    echo "<h3>Locker IOT</h3>";

       $nombredelalumno=$fila['fullname'];
         
	   
       // enviamos email
        
        $txtEspanol = "
        <html>
         <head>
           <title>".$asunto."</title>
         </head>
        <body>
          
          <p>Atendiendo a una solicitud de recuperaci&oacute;n de claves de acceso,
		  se ha procedido al env&iacute;o de este correo electr&oacute;nico facilitado en su formulario de registro. </p>
          
		   <p>Puede acceder directamente haciendo click en el siguiente enlace:</p>
		   <p>
           ".$acceso."
           </p>
		   <p>Tras su acceso podr&aacute; realizar el cambio de su clave por una nueva m&aacute;s f&aacute;cil de recordar para usted.</p>
		   <br>
		   <p>o dirigi&eacute;ndose en cualquier otro momento a <strong>www.lockeriot.com</strong></p>
		   <br>
		   <p>Gracias por su inter&eacute;s.</p>
		   <br>

			<p><p>
		   <br>
		   <p>Atentamente,</p>
           <br>
		   <p>&Oacute;scar Vicario Villa<br>
		   Locker IOT</p>
       </body>
       </html>
       ";
	   
	   $txtAleman = "
        <html>
         <head>
           <title>".$asunto."</title>
         </head>
        <body>
          
          <p>Als Reaktion auf eine Anfrage zur Wiederherstellung von Zugangscodes,
		  diese in Ihrem Registrierungsformular angegebene E-Mail wurde gesendet. </p>
          
		   <p>Sie k&ouml;nnen direkt zugreifen, indem Sie auf den folgenden Link klicken:</p>
		   <p>
           ".$acceso."
           </p>
		   <p>Nach der Anmeldung k&ouml;nnen Sie Ihr Passwort durch ein neues, das Sie sich leichter merken k&ouml;nnen, &auml;ndern.</p>
		   <br>
		   <p>oder adressieren zu jeder anderen Zeit an <strong>www.lockeriot.com</strong></p>
		   <br>
		   <p>Vielen Dank.</p>
		   <br>

			<p><p>
		   <br>
		   
           <br>
		   <p>&Oacute;scar Vicario Villa<br>
		   Locker IOT</p>
       </body>
       </html>
       ";
	   
	   $txtIngles = "
        <html>
         <head>
           <title>".$asunto."</title>
         </head>
        <body>
          
          <p>In response to a request for the recovery of access codes,
		  this email provided in your registration form has been sent. </p>
          
		   <p>You can access directly by clicking on the following link:</p>
		   <p>
           ".$acceso."
           </p>
		   <p>After logging in, you can change your password for a new one that is easier for you to remember.</p>
		   <br>
		   <p>or addressing at any other time to <strong>www.lockeriot.com</strong></p>
		   <br>
		   <p>Thanks.</p>
		   <br>

			<p><p>
		   <br>
		   
           <br>
		   <p>&Oacute;scar Vicario Villa<br>
		   Locker IOT</p>
       </body>
       </html>
       ";
	   
	   $cuerpo= espaleing($txtEspanol,$txtAleman,$txtIngles);
      //para el envío en formato HTML
      
        $headers = "MIME-Version: 1.0\n";
        $headers .= "Content-type: text/html; charset=iso-8859-1\n";
        
        $headers .= "From: Locker IOT<info@lockeriot.com>\n";
		//direcciones que recibirán copia oculta 
		$headers .= "Bcc: info@lockeriot.com , marcovicario@farmatural.com\n"; 
        //dirección de respuesta, si queremos que sea distinta que la del remitente
       $headers .= "Reply-To: info@lockeriot.com\n";

       //ruta del mensaje desde origen a destino
       $headers .= "Return-path: info@lockeriot.com\n";
        
      if(mail($_POST['emailsolicitante'],$asunto,$cuerpo,$headers))
       {
		$txtEspanol="Su clave de acceso ha sido enviada a la direcci&oacute;n de correo electr&oacute;nico indicada.";
		$txtAleman="Ihr Passwort wurde an die angegebene E-Mail-Adresse gesendet.";
		$txtIngles="Your password has been sent to the indicated email address.";
      echo "<p>".espaleing($txtEspanol,$txtAleman,$txtIngles)."<br/>";
      // echo "<strong>".$_POST['emailsolicitante']."</strong></br>";
	  
	    $txtEspanol="Por favor, revise su correo.";
		$txtAleman="Bitte &uulm;berpr&uulm;fen Sie Ihre E-Mail.";
		$txtIngles="Please check your email.";
	  
      echo espaleing($txtEspanol,$txtAleman,$txtIngles); 
      echo "</p>";
	  
		 
       }
      else  // falla la acción de enviar el e-mail
       {
		$txtEspanol="Ha habido un problema al intentar enviarle las claves a sus correo:";
		$txtAleman="Beim Versuch, die Schlüssel an Ihre E-Mail zu senden, ist ein Problem aufgetreten:";
		$txtIngles="There was a problem trying to send the keys to your email:";
      echo "<p>".espaleing($txtEspanol,$txtAleman,$txtIngles)."<br/>";
      echo "<strong>".$_POST['emailsolicitante']."</strong>";
	  
	    $txtEspanol="Por favor, pruebe de nuevo o cont&aacute;ctenos por e-mail.";
		$txtAleman="Bitte versuchen Sie es erneut oder kontaktieren Sie uns per E-Mail.";
		$txtIngles="Please try again or contact us by e-mail.";
	  
      echo espaleing($txtEspanol,$txtAleman,$txtIngles)."</p>";
      $mostrarformulariopeticion='s';
       }
	   
	   
	   
         


     }
  else
     {
     // 4)Si la dirección no es correcta o no encontramos el alumno, damos un mensaje de no encontrado y le invitamos a repetir la petición.
 
		$txtEspanol="El e-mail introducido no es correcto o no ha sido registrado. ";
		$txtAleman="Die eingegebene E-Mail ist nicht korrekt oder wurde nicht registriert.";
		$txtIngles="The e-mail entered is not correct or has not been registered.";   
 
	echo "<p>".espaleing($txtEspanol,$txtAleman,$txtIngles)."</p>";
   
    echo "<h3><b>".$_POST['emailsolicitante']."</b></h3>";
	
		$txtEspanol="Por favor, introduzca de nuevo su e-mail o regístrese como usuario.";
		$txtAleman="Bitte geben Sie Ihre E-Mail erneut ein oder registrieren Sie sich als Benutzer.";
		$txtIngles="Please enter your e-mail again or register as a user.";  
   
    echo "<p>".espaleing($txtEspanol,$txtAleman,$txtIngles)."</p>";
   

        $mostrarformulariopeticion='s';
     }


}

if($mostrarformulariopeticion=='s')
{
		$txtEspanol="Por favor, introduzca su e-mail para recuperar su clave de acceso";
		$txtAleman="Bitte geben Sie Ihre E-Mail-Adresse ein, um Ihr Passwort abzurufen";
		$txtIngles="Please enter your email to retrieve your password";
	
echo "<h1>".espaleing($txtEspanol,$txtAleman,$txtIngles)."</h1>";
 // Mostradmos Formulario de Solicitud de Clave
 echo '<form method="post" action="recoverpassword.php">';
 
 echo '<div id="accesoform">';
 
 echo '<ul>';
 echo '<li>';
 echo " e-mail :</li>";

 echo '<li>';
 echo '<input type="e-mail" name="emailsolicitante" size="50" />';
 echo '</li>';

 echo '<li>';
 echo " ";
 echo '</li>';
 
		$txtEspanol="recuperar clave de acceso";
		$txtAleman="Passwort abrufen";
		$txtIngles="retrieve password";
  
 echo '<li>'; 
 echo '<input class="botonacceso"  type="submit" value="'.espaleing($txtEspanol,$txtAleman,$txtIngles).'" />';
 echo '</li>';
 
 echo '</ul>';
 
 echo "</form>";

 
}

?>
	
	</article>

	</section>
	
	
	
	<?php  include ('piepagina.php');  ?>
	
	</body> 
	
</html>