<!DOCTYPE HTML>

<html lang="es">
<head>

	    <title><?php echo $_SESSION['titulopagina']; ?></title>
		<meta charset="utf-8">

		<meta name="description" content="<?php echo $_SESSION['description']; ?>" />
		<meta name="author" content="Oscar Vicario Villa" />
		<meta name="keywords" content="<?php echo $_SESSION['keywords']; ?>" />
		<meta name="robots" content="index, follow" />
		
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
				
		<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
		<link rel="apple-touch-icon" href="apple-touch-icon.png" />
		<link rel="apple-touch-icon" sizes="57x57" href="apple-touch-icon-57x57.png" />
		<link rel="apple-touch-icon" sizes="72x72" href="apple-touch-icon-72x72.png" />
		<link rel="apple-touch-icon" sizes="76x76" href="apple-touch-icon-76x76.png" />
		<link rel="apple-touch-icon" sizes="114x114" href="apple-touch-icon-114x114.png" />
		<link rel="apple-touch-icon" sizes="120x120" href="apple-touch-icon-120x120.png" />
		<link rel="apple-touch-icon" sizes="144x144" href="apple-touch-icon-144x144.png" />
		<link rel="apple-touch-icon" sizes="152x152" href="apple-touch-icon-152x152.png" />
		<link rel="apple-touch-icon" sizes="180x180" href="apple-touch-icon-180x180.png" />
		<link rel="stylesheet" type="text/css" href="css/impresora.css?nocache=<?php echo mt_rand();?>" media="print"/>
		<link rel="stylesheet" type="text/css" href="css/pantalla.css?nocache=<?php echo mt_rand();?>" media="screen"/>
		<link rel="stylesheet" type="text/css" href="css/iconos.css?nocache=<?php echo mt_rand();?>" media="screen"/>
		
		
<script src="js/jquery-1.11.2.min.js" type="text/javascript"></script>   
<script src="js/menu.js" type="text/javascript"></script>

</head>	

<body>





		
<header>
<?php 
		
		$direccion=$_SERVER['REQUEST_URI'];
		//Quitamos si existía ya la dirección
		$direccion=str_replace("&idioma=es","",$direccion);
		$direccion=str_replace("&idioma=de","",$direccion);
		$direccion=str_replace("&idioma=en","",$direccion);
		$direccion=str_replace("idioma=es","",$direccion);
		$direccion=str_replace("idioma=de","",$direccion);
		$direccion=str_replace("idioma=en","",$direccion);
		
		// vemos ti tiene parámetros pasados
		if(strpos($direccion,"?"))
			$direccion=$direccion."&";
		else
			$direccion=$direccion."?";


echo "<div id='idiomas'>";		
echo "<select name='selecIdioma' id='selecIdioma'>";

echo "<option ";
  if($_SESSION['idioma']=='de')
	  echo "selected";
echo " value='".$direccion."idioma=de'>Deutsch</option>";

echo "<option ";
  if($_SESSION['idioma']=='es')
	  echo "selected";
echo " value='".$direccion."idioma=es'>Espa&ntilde;ol</option>";

echo "<option ";
  if($_SESSION['idioma']=='en')
	  echo "selected";
echo " value='".$direccion."idioma=en'>English</option>";

echo "</select>";
echo "</div>"; // fin idiomas

echo "<script>";
echo " 

$('select#selecIdioma').change(function(){ 
    window.location = $(this).val();
});  

";
echo "</script>";



echo '<div class="logo_sos">';
		 echo '<img src="images/lockeriot.png?nocache='. mt_rand() . '" width="200" alt="" />';
echo '</div>';


if(!isset($_SESSION['estadousuario']) or $_SESSION['estadousuario']<1 ){
 
  echo "<div id='registro_cabecera'><span class='icon-enter'></span><a href='access.php' class='login'>".traduce("Acceso")."</a> </div>" ;
  echo "<div id='web_user'>&copy; ".date("Y")."  &Oacute;scar Vicario Villa</div>" ;
}
else{
// si está registrado muestra opcion de logout
  echo "<div id='registro_cabecera'><span class='icon-exit'></span><a href='finsesion.php' class='login'>".traduce("Salir")."</a></div>" ;
  echo "<div id='web_user'>".traduce("Usuario").": ".$_SESSION['nombre_completo']."</div>" ;
}

 


	
 
 
echo "</header>";  

echo "<div id='contenedor'>";  // se cierra en el pie de página	

?>