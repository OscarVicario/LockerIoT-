<?php

// Funciones de uso general para la aplicacion


function conecta($query)
   // conecta y devuelve en un array extrae una instruccion SQL query
{
	// hay que poner los datos correctos seg�n el servidor
$servername = "nombreServidor";
$database = "nombreBaseDatos";
$username = "usuarioBaseDatos";
$password = "passwordBaseDatos";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);   

    return mysqli_query($conn, $query);

}

 
function comprobar_email($email){
    $mail_correcto = 0;
    //compruebo unas cosas primeras
    if ((strlen($email) >= 6) && (substr_count($email,"@") == 1) && (substr($email,0,1) != "@") && (substr($email,strlen($email)-1,1) != "@"))
    {
       if ((!strstr($email,"'")) && (!strstr($email,"\""))&& (!strstr($email,"\$"))&& (!strstr($email," ")) && (!strstr($email,'//'))){
          //miro si tiene caracter .
          if (substr_count($email,".")>= 1){
             //obtengo la terminacion del dominio
             $term_dom = substr(strrchr ($email, '.'),1);
             //compruebo que la terminación del dominio sea correcta
             if (strlen($term_dom)>1 && strlen($term_dom)<5 && (!strstr($term_dom,"@")) ){
                //compruebo que lo de antes del dominio sea correcto
                $antes_dom = substr($email,0,strlen($email) - strlen($term_dom) - 1);
                $caracter_ult = substr($antes_dom,strlen($antes_dom)-1,1);
                if ($caracter_ult != "@" && $caracter_ult != "."){
                   $mail_correcto = 1;
                }
             }
          }
       }
    }
    if ($mail_correcto)
       return 1;
    else
       return 0;
}


function dameIPusuario() {
   if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
       $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    elseif (isset($_SERVER['HTTP_VIA'])) {
       $ip = $_SERVER['HTTP_VIA'];
    }
    elseif (isset($_SERVER['REMOTE_ADDR'])) {
       $ip = $_SERVER['REMOTE_ADDR'];
    }
    else {
       $ip = "DESCONOCIDA";
    }

    return addslashes($ip);
    
}

function envioEmailAlertaPuertaAbierta($emaildestinatario,$numeroLocker, $localizacion, $fechahoraapertura, $minsaviso, $clave_get ){
	       // enviamos email
		$acceso="<a href='https://www.lockeriot.com/access.php?cl=". $clave_get."&us=".$emaildestinatario."'>https://www.lockeriot.com</a>";
        $asunto="LockerIOT: Alert! Your Locker is open.";
        $cuerpo= "
        <html>
         <head>
           <title>".$asunto."</title>
         </head>
        <body>";
		
		$cuerpo.= "<p>Diese automatische E-Mail wurde gesendet, nachdem festgestellt wurde, dass sich Ihre Schlie&szlig;fachnummer ".$numeroLocker. " befindet sich in :</p>";
		$cuerpo.= "<p>". $localizacion. "</p> <p>ist ge&ouml;ffnet seit: ".$fechahoraapertura." </p>";
		$cuerpo.= "<p>und hat die ".$minsaviso." Minuten &Ouml;ffnungszeit &uuml;berschritten, die Sie f&uuml;r den Erhalt dieser Benachrichtigung festgelegt haben.</p> 
          
		   <p>Bitte &uuml;berpr&uuml;fen Sie den Status Ihres Schlie&szlig;fachs.</p><p>Wenn Sie es bereits geschlossen haben, k&ouml;nnen Sie diese Nachricht ignorieren.</p>
		   <p>Sie k&ouml;nnen direkt &uuml;ber den folgenden Link darauf zugreifen.</p>";
		   
		$cuerpo.= "</br>  <p>
           ".$acceso."
           </p>
		   <br>";
        
		$cuerpo.="<p>-----------------</p>";
		
		$cuerpo.= "<p>This automatic email has been sent after detecting that your Locker Num. ".$numeroLocker. " located at :</p>";
		$cuerpo.= "<p>". $localizacion."</p> <p>has been open since: ".$fechahoraapertura." </p>";
		$cuerpo.= "<p>and has exceeded the ".$minsaviso." minutes open time limit you have set to receive this notice.</p>
          
		   <p>Please check the status of your Locker.</p><p>If you have already closed it you can ignore this message.</p>
		   <p>You can access it directly from the following link. </p>";
		   
		$cuerpo.= "</br>  <p>
           ".$acceso."
           </p>
		   <br>";
		   
		$cuerpo.="<p>-----------------</p>";
		

        $cuerpo.= "<p>Este email autom&aacute;tico ha sido enviado tras detectar que su Taquilla/Locker Num. ".$numeroLocker. " situado en :</p>";
		$cuerpo.= "<p>". $localizacion."</p> <p>lleva abierto desde: ".$fechahoraapertura." </p>";
		$cuerpo.= "<p>y ha superado el l&iacute;mite de ".$minsaviso." minutos de tiempo de apertura que usted ha establecido para recibir este aviso.</p>
          
		   <p>Por favor, verifique el estado de su Locker.</p><p>Si ya lo ha cerrado puede ignorar este mensaje.</p>
		   <p> Puede acceder directamente desde el siguiente enlace. </p>";
	
		 
        $cuerpo.= "</br>  <p>
           ".$acceso."
           </p>
		   <br>
		   <p> Mit freundlichen Gr&uuml;&szlig;en, | Sincerely yours, | Atentamente,</p>
           <br>
		   <p>Locker IOT</p>
		   <p><strong>www.lockeriot.com</strong></p>";
		
		$cuerpo.= "   
       </body>
       </html>
       ";
      //para el env��o en formato HTML
      
        $headers = "MIME-Version: 1.0\n";
        $headers .= "Content-type: text/html; charset=iso-8859-1\n";
        
        $headers .= "From: Locker IOT<info@lockeriot.com>\n";
		//direcciones que recibir��n copia oculta 
		$headers .= "Bcc: info@lockeriot.com , marcovicario@farmatural.com\n"; 
        //direcci��n de respuesta, si queremos que sea distinta que la del remitente
       $headers .= "Reply-To: info@lockeriot.com\n";

       //ruta del mensaje desde origen a destino
       $headers .= "Return-path: info@lockeriot.com\n";
        
      mail($emaildestinatario,$asunto,$cuerpo,$headers);
	
	
	
}




function pontextoleyprotecciondatos()
{

echo utf8_encode('
<p>
Conforme a las leyes de protecci&oacute;n de datos de car&aacute;cter personal, notificamos a todos nuestros usuarios: 
que la solicitud de sus datos para el registro y acceso como usuario tiene como &uacute;nica finalidad realizar la prestaci&oacute;n
 del servicio solicitado; que se han adoptado medidas t&eacute;cnicas y organizativas tanto para garantizar la seguridad e integridad
 de esos datos como para evitar su tratamiento o acceso no autorizado, alteraci&oacute;n o p&eacute;rdida; 
 que dichos datos son introducidos en un fichero informatizado cuya &uacute;nica finalidad es la gesti&oacute;n y control 
 de todas aquellas acciones internas necesarias para realizar la prestaci&oacute;n del servicio solicitado; 
 que conforme a las leyes de protecci&oacute;n de datos de car&aacute;cter personal pueden ejercer sus derechos, 
 para lo cual pueden dirigirse a la direcci&oacute;n de correo electr&oacute;nico info@lockeriot.com 
 indicando en el asunto "Referencia: protecci&oacute;n de datos".</p>
 
 <p>
 Se requiere el uso de una cookie t&eacute;cnica para el seguimiento de su sesi&oacute;n, por lo que ha de tener permitido el uso de cookies en su navegador.
 </p>' );

}

function pontextoleyprotecciondatosingles()
{

echo utf8_encode('
<p>
Under the laws on protection of personal data, we inform all users: that details
are requested from them for registration and access as users for the sole
purpose of providing the service requested; that technical and organizational
measures have been taken to ensure the security and integrity of these details
and to avoid their processing or unauthorized access, alteration or loss; that
these details are entered into a computer file for the sole purpose of managing
and controlling all the internal procedures necessary for providing the requested
service; that pursuant to the laws on the protection of personal data they can
exercise their rights by sending an email to info@lockeriot.com specifying
"Reference: data protection".</p>

<p>
 A technical cookie is required to keep track of your session; check that cookies are enabled in your browser. 
 </p>' );

}

function accesoRobots()
{

// creamos $_SESSION['estadousuario'] si no existe, para evitar errores de notificaci�n
 if(!isset($_SESSION['estadousuario']))
    $_SESSION['estadousuario']=0;

 // esta funcion detecta si el visitante es un robot, spider o crawler .
 if($_SESSION['estadousuario']<1){
  // solo actua si no se ha establecido estado de usuario
 if(strpos($_SERVER['HTTP_USER_AGENT'],'bot') 
 or strpos($_SERVER['HTTP_USER_AGENT'],'spider') 
 or strpos($_SERVER['HTTP_USER_AGENT'],'Spider')
 or strpos($_SERVER['HTTP_USER_AGENT'],'crawler')){
  
 
   $_SESSION['email']="robot";
  
  
 if(strpos($_SERVER['HTTP_USER_AGENT'],'majestic12')){
   $_SESSION['email']="majestic12";
   } 
 if(strpos($_SERVER['HTTP_USER_AGENT'],'yahoo')){
   $_SESSION['email']="yahoo";
   }   
 if(strpos($_SERVER['HTTP_USER_AGENT'],'baidu')){
   $_SESSION['email']="baidu";
   } 
if(strpos($_SERVER['HTTP_USER_AGENT'],'360Spider')){
   $_SESSION['email']="360Spider";
   } 
 if(strpos($_SERVER['HTTP_USER_AGENT'],'sogou')){
   $_SESSION['email']="sogou";
   }  
 if(strpos($_SERVER['HTTP_USER_AGENT'],'google')){
   $_SESSION['email']="google";
   }  // Google en ultima posiciun para asegurarlo    
 
 
 }  // fin es robot
} // fin sin estado usuario
} // fin funcion

function acumulasegsypags()
{
// Esta funcion acumula segundos sobre la variable de sesion $_SESSION['segsacum']
// En caso de que ha transcurrido mas de 5 minutos desde la anterior, acumula segundos en la base de datos para cualquier usuario registrado
// tambien acumula paginas visitadas y las acumula en la base de datos cada vez
// En cada sesion, pueden perderse hasta 5 minutos y las paginas vistas en esos altimos 5 minutos
if(!isset($_SESSION['pagsacum']))
    $_SESSION['pagsacum']=1;
else	
    $_SESSION['pagsacum']++;


// tomamos el instante de ahora.
$ahora=time();

// Tomamos la primera vez el ultimo tiemp
if(!isset($_SESSION['ultimotiempo']))
 $_SESSION['ultimotiempo']=time();
 

if($ahora-$_SESSION['ultimotiempo']>300 and $_SESSION['estadousuario']>0)
{
$acumularsegs=$ahora-$_SESSION['ultimotiempo'];
// dejamos registro nuevo ultimotiempo
$_SESSION['ultimotiempo']=$ahora;

// acumulamos segundos y paginas en la base de datos
$query="UPDATE sosusers SET segsacum = (segsacum + ".$acumularsegs.") , pagsacum = (pagsacum + ".$_SESSION['pagsacum'].") WHERE useremail = '" .$_SESSION['email']."'" ;
$result = conecta($query);

// ponemos a 0 el contador de paginas
$_SESSION['pagsacum']=0;

}

// Guardamos en tabla historial paginas visitadas 
$ipusuario=dameIPusuario();
$emailoip= isset($_SESSION['email']) ? $_SESSION['email'] : $ipusuario ;

$busqueda="";

$query="INSERT INTO xueshenglishi ( email , sesion, ipusuario , url, useragent ) 
	 VALUES ('".$emailoip. "' , '".session_id()."' , '".$ipusuario."' , '".$_SERVER['REQUEST_URI'].$busqueda."' , '".$_SERVER['HTTP_USER_AGENT'] ."' )";
$result = conecta($query);


} // fin funciun


function guardaindexnorden($norden)
{
 if(!isset($_SESSION['indicenord']))
   $_SESSION['indicenord']=0;
 // guardamos el n�mero de orden en el array de indices 
 $_SESSION['arrayindexnorden'][$_SESSION['indicenord']]=$norden;
 // incrementamos el indice para la siguiente vez
 $_SESSION['indicenord']++;
 // devuelve el indice anterior, tal y como estaba cuando fue llamada la funci�n
 return $_SESSION['indicenord']-1;
 
} // fin funciun

function compruebasesionusuario()
{
// no se usa
}

function accesousuarios()
{
if((isset($_POST['userid']) and isset($_POST['password']) and strlen($_POST['userid'].$_POST['password'])>0 ) or (isset($_GET['cl']) and isset($_GET['us'])))
{

 if (isset($_POST['userid']) and isset($_POST['password'])){
	 

		// comprobamos que el userid es un email
		  if(comprobar_email(strtolower($_POST['userid'])))
			$userid = strtolower($_POST['userid']);
		  else
			$userid = 'noemail'; 

			$query = "select * from users  where email='".$userid."' and clave=SHA1('".$_POST['password']."')";
   
   }else{
	   $userid = strtolower($_GET['us']);
	   $query = "select * from users  where email='".$userid."' and clave='".$_GET['cl']."'";
   }	   
	  
           

  $result = conecta($query);



  if (mysqli_num_rows($result) >0 )
   { 
      $resultado=mysqli_fetch_array($result);
      $_SESSION['email'] = $resultado['email'];
	  $_SESSION['iduser'] = $resultado['iduser'];
	  
	  $_SESSION['groupsadmin'] = $resultado['groupsadmin'];
	  $_SESSION['generaladmin'] = $resultado['generaladmin'];
	  
	  // cargamos datos adicionales
	  $_SESSION['nombre_completo'] =$resultado['fullname'];
	  $_SESSION['telefono']=$resultado['telephone'];
	 
	  
	 
	
	   // por defecto son usuarios que est��n en la base de datos tienen estado 2 
	   $_SESSION['estadousuario'] = 2;
	   
	 
	   
	   // ultimo acceso (anterior)
	   $_SESSION['ultacceso'] = $resultado['lastaccess'];
	   

	// guarda en fichero la fecha con que se hizo el nuevo acceso correcto y el codigo de la actual sesion
		  $query2="UPDATE users SET lastaccess = '".date("Y-m-d H:i:s",time())."' , accesos = accesos+1 , sesion = '".session_id()."' , ultimaip = '".dameIPusuario()."' WHERE iduser=".$_SESSION['iduser'] ;
		  $result2 = conecta($query2);	 
			

   }
   else
   {
     // no está registrado
	 
	
	 // no es un alumno ni está registrado
	 $_SESSION['estadousuario']=0;
	 // marca de intento fallido
	 $_SESSION['intentofallido']=1;
	 
   }

   
// Guardamos datos de acceso en una base de datos de accesos 
// conecta y graba un registro de accesos a la web
$query="insert into accs (iduser,usu,ipusuario, sesion ,estadousuario) values
                ( ". (isset($_SESSION['iduser']) ? $_SESSION['iduser'] :0 )  ." , '".$userid."' , '".dameIPusuario()."' , '".session_id()."' , ".$_SESSION['estadousuario']." )";

$result = conecta($query);  

$otracc='Respuestas_OK';

$query="insert into otraccs (otracc) values
                ( '". $otracc ."')";

//  $result = conecta($query);  // no guardamos estos registros en la base de datos 15/9/21


}
}

// crea codigo QR
function creaQR($refaccess){

// crea una imagen png en la carpeta qr con el QR correspondiente
	$textoParaCodigoQR="https://www.lockeriot.com/registration.php?refaccess=".$refaccess;

	$imagenQR="qr/".$refaccess.".png";
	

	include('phpqrcode/qrlib.php'); 	
	QRcode::png($textoParaCodigoQR, $imagenQR );
	
}


function generaClaveAlfanumerica($length = 10) { 
    return substr(str_shuffle("123456789abcdefghijkmnopqrstuvwxyzABCDEFGHIJKLMNPQRSTUVWXYZ"), 0, $length); 
} 



function limpiaCadena($cadena) { 
// quita todo lo que no sea letras o numeros
     return ereg_replace("[^A-Za-z0-9]", "",  $cadena); 
} 

function ponIdioma(){
	if(!isset($_SESSION['idioma']))
		$_SESSION['idioma']="de";  // por defecto aleman
	
	if(isset($_GET['idioma']) and $_GET['idioma']=='es')
		$_SESSION['idioma']="es";   // espa?ol
	
	if(isset($_GET['idioma']) and $_GET['idioma']=='de')
		$_SESSION['idioma']="de";   // alem��n
	
	if(isset($_GET['idioma']) and $_GET['idioma']=='en')
		$_SESSION['idioma']="en";  // ingl��s
}

function traduce($textoEsp=""){
	if(!isset($_SESSION['idioma']))
		$_SESSION['idioma']="de";  // por defecto aleman

	
    // buscamos texto en array de traduccion
    $diccionario = array(
	"Texto en Espa&ntilde;ol" , "Deutscher text", "English text",
	
	"Acceso","Einloggen", "Login", 
	"Registro","Registrierung", "Registration",
	"Salir","Ausfahrt", "Exit",
	"Usuario","Benutzername","User",
	"Inicio", "Startseite", "Home",
	
	"Acceso usuarios" , "Benutzerzugriff", "User access",
	"Clave", "Passwort", "Password",
	"ADVERTENCIA","WARNUNG","WARNING",
	
	"Actualizar", "Update", "Update",
	"Minutos con taquilla abierta.", "Minuten bei ge&ouml;ffnetem Schlie&szlig;fach.", "Minutes with the locker open.",
	"guardar","speichern","save",
	
	"Nombre completo","Voller Name","Full Name",
	"Tel&eacute;fono","Telefon","Phone",
	"Repita","Wiederholen","Repeat",
	"Datos requeridos","Ben&ouml;tigte Daten","Required data",
	"continuar","fortsetzen","continue",
	
	"Presentaci&oacute;n", "Vorstellung","Presentation",
	
	"Gesti&oacute;n", "Management", "Management",
	"Contacto", "Kontakt", "Contact",
	"Enlaces", "Links", "Links",
	
	"Cambiar Clave", "Passwort &auml;ndern", "Change Password",
	 
	
	
	"Espa&ntilde;ol" , "Deutsch" , "English"
	);	
	
	$posicion=array_search($textoEsp, $diccionario);
	if($posicion){
		
		if($_SESSION['idioma']=='es')
			return $diccionario[$posicion];
		
		if($_SESSION['idioma']=='de')
		  return $diccionario[$posicion+1];
	  
	    if($_SESSION['idioma']=='en')
		  return $diccionario[$posicion+2];
		
	}
	else{
		if($_SESSION['idioma']=='de')
			return $textoEsp."(***Deutsch***)";
		if($_SESSION['idioma']=='en')
			return $textoEsp."(***English***)";
		if($_SESSION['idioma']=='es')
			return $textoEsp."(***FaltaTraducctor***)";
	}
		
	
}

function espale($textoEsp,$textoAle){
	// esta funcion pone el texto en espa?ol o alem��n seg��n sea el idioma
	if(!isset($_SESSION['idioma']))
		$_SESSION['idioma']="de";  // por defecto aleman
	
	if($_SESSION['idioma']=="es")
			return $textoEsp;  
	else
		    return $textoAle; 
}


function espaleing($textoEsp,$textoAle, $textoIng){
	// esta funcion recibe 3 textos y pone el texto en espa?ol , alem��n o ingl��s seg��n sea el idioma
	if(!isset($_SESSION['idioma']))
		$_SESSION['idioma']="de";  // por defecto aleman
	
	if($_SESSION['idioma']=="es")
			return $textoEsp;  
	if($_SESSION['idioma']=="de")
		    return $textoAle; 
	if($_SESSION['idioma']=="en")
		    return $textoIng;
}





?>
