<?php
session_start();
require('general_func.php');
ponIdioma();

// Variables para datos de cabecera
$_SESSION['titulopagina']="Locker IOT By Oscar Vicario";
$_SESSION['description']="Locker IOT By Oscar Vicario";
$_SESSION['keywords']="";
// Establecemos la pagina de idioma alternativo
        $_SESSION['cambiaidioma']="../";

  	include ('cabecera.php'); 

	include ('menunavegacion.php');  

	
 	
	 

?>	
<section>

	<article>
	
		<h1 class="siloprimero">Locker IOT</h1>
		
<?php 
$txtEspanol="Taquilleros controlados por Internet";
$txtAleman="Internet-gesteuerte Schlie&szlig;fach-Sets";
$txtIngles="Internet-controlled locker sets";
echo "<h1 class='siloprimero'>". espaleing($txtEspanol,$txtAleman,$txtIngles)."</h1>"; 

?>		
		
		<p  class="fotocvv" >
  <img  src="images/prototipo1.jpg?nocache=<?php echo mt_rand();?>" style="border-radius: 13px;" alt="The 1st Prototype"/>
		</p>

	</article>
	
</section>
	


<?php  include ('piepagina.php');  ?>
	
</body> 
	
</html>