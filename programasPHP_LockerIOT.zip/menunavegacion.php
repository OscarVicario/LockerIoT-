<?php

// menu para navegación 

    echo '<div class="menu_bar">
			<a href="#" class="bt-menu"><span class="icon-menu"></span></a>
		</div>';
		
	echo '<nav>';	

		echo '<ul>';

			if(strpos( $_SERVER["SCRIPT_NAME"], "index.php" )==false)
			  {
			   echo '<li><span class="icon-home3"></span><a href="index.php">'.traduce("Inicio").'</a>';
			  }
			  else
			  {
			   echo '<li class="urlactual"><span class="icon-home3"></span>'.traduce("Inicio");
			  }
			echo '</li>';
			
		
			if(strpos( $_SERVER["SCRIPT_NAME"], "contact.php" )==false)
			  {
			   echo '<li><span class="icon-envelop"></span><a href="contact.php">'.traduce("Contacto").'</a>';
			  }
			  else
			  {
			   echo '<li class="urlactual"><span class="icon-envelop"></span>'.traduce("Contacto");
			  }
			echo '</li>';		

	if(isset($_SESSION['estadousuario']) and $_SESSION['estadousuario']>=1 ){
		echo '<li><a href="access.php">Lockers</a></li>';
		if(isset($_SESSION['iduser']) and $_SESSION['iduser']<=2 )  // solo Oscar y Marco
				echo '<li><a href="robotarm/">Robot</a></li>';
		echo '<li><a href="access.php?cambioclave=1" >'.traduce("Cambiar Clave").'</a></li>';
	}
	

	
	if(isset($_SESSION['groupsadmin']) and $_SESSION['groupsadmin']>=1 ){
		echo '<li><a href="adminmenu.php">Admin. Menu</a></li>';
	}
			
			
		echo '</ul>';
	
	echo '</nav>';
?>	