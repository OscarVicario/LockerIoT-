<?php
session_start();
require('general_func.php');
ponIdioma();
// Variables para datos de cabecera
$_SESSION['titulopagina']="Registrierung | Locker IOT";
$_SESSION['description']="Formular zur Benutzerregistrierung";
$_SESSION['keywords']="Locker IOT";





// ponemos cabeceras y menu
 	
	
	  include ('cabecera.php'); 
	  include ('menunavegacion.php'); 
	
 	
	echo "<section>";
	
	echo "<article> <span class='no_selection'>";

// creamos variables de sesion si no existen
if(!isset($_SESSION['nuevoemail']))
{
	$_SESSION['nuevoemail']="";
	$_SESSION['nuevonombre']="";
	$_SESSION['nuevotelefono']="";
	$_SESSION['refaccess']="";
}

// Si se recibe post del formulario se actualizan variables de sesion
if(isset($_POST['nuevoemail']))
{
	$_SESSION['nuevoemail']=strtolower(strip_tags($_POST['nuevoemail']));
	$_SESSION['nuevonombre']=strip_tags($_POST['nuevonombre']);
	$_SESSION['nuevotelefono']=strip_tags($_POST['nuevotelefono']);
	$_SESSION['refaccess']=strip_tags($_POST['refaccess']);
}

// si trae la referencia por get, la tomamos
if (isset($_GET['refaccess'])){
	$_SESSION['refaccess']=strip_tags($_GET['refaccess']);
	// echo $_GET['refaccess'];
}
	



// variable para corregir datos
$nocorregir=1;
if(isset($_GET['acc']) and $_GET['acc']=='corr' )
	$nocorregir=0;

// variable para controlar que el email es correcto
$emailok=1;
$emailrepetidook=1;
$emailyaexistente=0;

// comprobamos que los dos email sean iguales
if(isset($_POST["renuevoemail"]) and $_POST['renuevoemail']<>$_POST['nuevoemail'])
{
	$emailrepetidook=0;
}
else
{
// si el nuevoemail no es un email lo borramos.
if(comprobar_email($_SESSION['nuevoemail'])){
	// comprobamos si ya existe en la base de datos de usuarios
	$query = "select * from users where email='".$_SESSION['nuevoemail']."'" ;

  $result = conecta($query);


  if (mysqli_num_rows($result) >0 )
   { 
	// El email ya existe
	$emailyaexistente=1;
	$emailok=0;
   }
   
   // comprobamos si ya existe como email bloqueado.
	
}
else{
	$_SESSION['nuevoemail']="";
	$emailok=0;
}

}

$existetaquillero=0;
$direcciontaquillero="";
// identificamos si existe el grupo de taquillas con esa referencia de acceso
$query = "select * from groups where refaccess='".$_SESSION['refaccess']."'" ;

  $result = conecta($query);


  if (mysqli_num_rows($result) >0 )
   { 
	$fila = mysqli_fetch_assoc($result);
	// existe el grupo. CORRECTO
	$existetaquillero=1;
	$direcciontaquillero=$fila['address']." | ".$fila['address2']." | ".$fila['place']." | ".$fila['country'];
	$_SESSION['nuevoidgroup']=$fila['idgroup'];  // servirá para dar de alta al usuario en este grupo inicialmente
   }


// variable para controlar el nombre
$nombreok=1;
if(strlen(trim($_SESSION['nuevonombre']))>0){
	
}
else{
	$nombreok=0;
}



// variable para controlar el telefono
$telefonook=1;
if(strlen(trim($_SESSION['nuevotelefono']))>0){
	 
}
else{
	$telefonook=0;
}


// en funcion de resultados se compone la página
if(isset($_SESSION['estadousuario']) and $_SESSION['estadousuario']>=1 )
{
	// Ponemos el nombre del usuario
	echo '<div id="accesoform">';
  echo "<p>".traduce("Nombre completo").": <strong>" . $_SESSION['nombre_completo']."</strong></p>";
  
  echo '</div>';
	
	// Si no está caducado damos bienvenida y mostramos las opciones de usuario ok
	echo " ";
}
else
{

if($emailok and $nombreok and $telefonook and $existetaquillero and $nocorregir )
{

// Si ha introducido datos completos los mostramos y tiene opción de corregir o pasar al alta.
	
  $txtEspanol="<h1>Solicitud de registro como usuario </h1>"; 
  $txtAleman="<h1>Antrag auf Benutzerregistrierung </h1>";
  $txtIngles="<h1>User registration request </h1>";
  echo espaleing($txtEspanol,$txtAleman,$txtIngles);

	
  echo '<div id="accesoform">';
  echo "<p>".traduce("Nombre completo").": <strong>" . $_SESSION['nuevonombre']."</strong></p>";
 
  echo "<p>e-mail: <strong>" . $_SESSION['nuevoemail']."</strong></p>";
  echo "<p>".traduce("Tel&eacute;fono").": <strong>" . $_SESSION['nuevotelefono']."</strong></p>";
  echo "<p>Ref.Locker : <strong>" . $direcciontaquillero."</strong></p>";

  echo "<p class='aviso'>";
  echo espaleing("Por favor, revise que todos sus datos son correctos antes de continuar. Gracias.","Bitte überprüfen Sie, ob alle Ihre Angaben korrekt sind, bevor Sie fortfahren. Ich danke Ihnen.","Please check that all your information is correct before proceeding. Thank you.");

  echo "<br>";
 
  echo espaleing("Si algún dato no es correcto, pulse","Wenn Daten falsch sind, drücken Sie","If any data is not correct, press");

  echo "<a href='registration.php?acc=corr' class='login'>";
   
  echo espaleing("modificar","ändern.","modify");
  echo "</a> </p>";
  echo "<p><a href='sendrequest.php' class='login'>";
  
  echo espaleing("continuar","Fortsetzung","continue");
  echo "</a></p>";
  echo '</div>';
  

}
else
{

// Si ha intoducido datos incompletos lo indicamos 
if($emailyaexistente==1) 
	  echo '<p class="aviso">El e-mail ya existe como usuario de esta web. Por favor, vaya a <a href="access.php" class="login">Acceso</a> </p>';
  
if($emailrepetidook==0) 
	  echo '<p  class="aviso">e-mail incorrecto (dato requerido)<br>
							  Por favor, revise su e-mail y la coincidencia al repetirlo.</p>';
  
 if(strlen($_SESSION['nuevoemail'].$_SESSION['nuevonombre'].$_SESSION['nuevotelefono'])>0)
 {
  if($emailok==0) 
	  echo '<p  class="aviso">e-mail incorrecto (dato requerido)</p>';
  
  if($nombreok==0) 
	  echo '<p  class="aviso">Nombre no indicado (dato requerido)</p>';
  
  if($telefonook==0) 
	  echo '<p  class="aviso">Telephone (dato requerido)</p>';
  
  
 }


	
	// Cuadro con información sobre precio y forma de pago
	
  
// Crea formulario para el registro
	  $txtEspanol="<h1>Solicitud de registro de usuario | Por favor, rellene este formulario.</h1>";
      $txtAleman="<h1>Anfrage zur Benutzerregistrierung | Bitte dieses Formular ausfüllen.</h1>";
      $txtIngles="<h1>User registration request | Please fill in this form.</h1>";
  
  echo espaleing($txtEspanol,$txtAleman,$txtIngles);
	

		echo '<div id="accesoform">';

     echo '<form method="post" action="registration.php">';
	 echo '<ul>';
     
	 echo '<li>'.traduce("Nombre completo").'<span class="asterisco">*</span>:<input type="text" name="nuevonombre" size="30" value="'.$_SESSION['nuevonombre'].'"/></li>';
	 //echo '<li>Nachname <span class="asterisco">*</span>:<input type="text" name="nuevoapellido" size="30" value="'.$_SESSION['nuevoapellido'].'"/></li>';
	 echo '<li>e-mail <span class="asterisco">*</span>:<input type="e-mail" name="nuevoemail" size="30" value="'.$_SESSION['nuevoemail'].'" /></li>';
	 echo '<li>'.traduce("Repita").' e-mail <span class="asterisco">*</span>:<input type="e-mail" name="renuevoemail" size="30" value="" /></li>';
	 echo '<li>'.traduce("Tel&eacute;fono").'<span class="asterisco">*</span>:<input type="text" name="nuevotelefono" size="30" value="'.$_SESSION['nuevotelefono'].'"/></li>';
	 echo '<li>Ref.Locker: <span class="asterisco">*</span>:<input type="text" name="refaccess" size="30" value="'.$_SESSION['refaccess'].'"/></li>';

	 echo '<li><input class="botonacceso" type="submit" value="'.traduce("continuar").'" /></li>';
	 echo '<li><span class="asterisco">* <em>'.traduce("Datos requeridos").'</em></span></li>';
	 
	 echo '</ul>';
	 
     echo '</form>';

	echo '</div><!-- cierre div #accesoform -->';
	
	
	
	// Texto ley proteccion de datos
	echo '<br>';
	
	echo '<div class="protecciondatos">';
	// pontextoleyprotecciondatos();
	  $txtEspanol='De acuerdo con las leyes de protección de datos de carácter personal, informamos a todos nuestros usuarios que la única finalidad de solicitar sus datos para el registro y acceso como usuario es la prestación del servicio solicitado; que se han adoptado las medidas técnicas y organizativas necesarias para garantizar tanto la seguridad e integridad de dichos datos como para evitar su tratamiento o acceso no autorizado, su modificación o su pérdida; que los datos serán introducidos en un fichero automatizado cuya única finalidad es la gestión y el control de todas aquellas actuaciones internas necesarias para llevar a cabo el servicio solicitado; que, de acuerdo con la legislación sobre protección de datos de carácter personal, pueden ejercer sus derechos, para lo cual pueden dirigirse a la dirección de correo electrónico info@lockeriot.com indicada en el asunto "Referencia: Protección de Datos".
				<br>
			  El uso de una cookie técnica es necesario para controlar su sesión, por lo que debe permitir el uso de cookies en su navegador'; 
      $txtAleman='In Übereinstimmung mit den Gesetzen zum Schutz personenbezogener Daten weisen wir alle unsere Benutzer darauf hin, dass der einzige Zweck der Anforderung ihrer Daten für die Registrierung und den Zugriff als Benutzer darin besteht, den angeforderten Dienst bereitzustellen; dass technische und organisatorische Maßnahmen ergriffen wurden, um sowohl die Sicherheit und Integrität dieser Daten zu gewährleisten als auch deren Verarbeitung oder unbefugten Zugriff, Änderung oder Verlust zu verhindern; dass die Daten in eine computergestützte Datei eingegeben werden, deren einziger Zweck die Verwaltung und Kontrolle all jener internen Maßnahmen ist, die zur Durchführung der angeforderten Dienstleistung erforderlich sind; dass sie gemäß den Gesetzen zum Schutz personenbezogener Daten ihre Rechte ausüben können, für die sie sich an die E-Mail-Adresse info@lockeriot.com wenden können, die im Betreff "Referenz: Datenschutz" angegeben ist.
				<br>
			  Die Verwendung eines technischen Cookies ist erforderlich, um Ihre Sitzung zu überwachen, daher muss die Verwendung von Cookies in Ihrem Browser zugelassen werden.';

      $txtIngles="In accordance with the laws on the protection of personal data, we inform all our users that the sole purpose of requesting their data for registration and access as a user is to provide the requested service; that technical and organizational measures have been adopted to ensure both the security and integrity of this data and to prevent its processing or unauthorized access, modification or loss; that the data will be entered into a computerized file whose sole purpose is the management and control of all those internal actions necessary to carry out the requested service; that, in accordance with the laws on the protection of personal data, they can exercise their rights, for which they can contact the e-mail address info@lockeriot.com indicated in the subject Reference: Data Protection
				<br>
				The use of a technical cookie is necessary to monitor your session, so you must allow the use of cookies in your browser.";
  
  echo espaleing($txtEspanol,$txtAleman,$txtIngles);
	
	echo '</div>';
	echo '<br>';
	echo '<br>';
	
	
}
}
?>	 

	
	 
	</span>
	</article>

	</section>
	
	
	
	<?php  include ('piepagina.php');	?>
	
	</body> 
	
</html>