<?php

session_start();
require('general_func.php');
ponIdioma();
$idioma=$_SESSION['idioma']; // guardamos el idioma en variable antes de destruir sesion

session_destroy();

$_GET['idioma']=$idioma;
ponIdioma();
$_SESSION['estadousuario']=0;
 

 
// Variables para datos de cabecera
$_SESSION['titulopagina']="Fin Sesión ";
$_SESSION['description']="";
$_SESSION['keywords']="";


?>
	<?php  	include ('cabecera.php');  ?>
	
	<?php   include ('menunavegacion.php');  ?>
	
 	
	<section>
	
	<article><span class='no_selection'>
	
<?php

$txtEspanol="<h1>Ha finalizado la sesión...</h1>
	 <p>Muchas gracias por su interés.</p>";
$txtAleman="<h1>Sitzung beendet...</h1>
	 <p>Vielen Dank für Ihr Interesse.</p>";
$txtIngles="<h1>Session ended...</h1>
	 <p>Thank you very much for your interest.</p>";
echo espaleing($txtEspanol,$txtAleman,$txtIngles);
	 
	 
?>

	</span>
	</article>
	
	
	
	
	

	
	</section>
	
	
	
	<?php  include ('piepagina.php');  ?>
	
	</body> 
	
</html>

	