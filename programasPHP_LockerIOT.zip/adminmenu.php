<?php
session_start();
require('general_func.php');
ponIdioma();
// Variables para datos de cabecera
$_SESSION['titulopagina']="Locker IOT Administration Menu";
$_SESSION['description']="Locker Administration Menu ";
$_SESSION['keywords']="Locker IOT";



// ponemos cabeceras y menu
 	
	
	  include ('cabecera.php'); 
	  include ('menunavegacion.php'); 
	
 	
	echo "<section>";
	
	echo "<article><span class=''>";



// en funcion de resultados se compone la página
if(isset($_SESSION['groupsadmin']) and $_SESSION['groupsadmin']>=1 )
{

if(isset($_GET['lockergroup']) and intval($_GET['lockergroup'])>0){
	// pantalla para imprimir qr para regisrtro
	echo "<a href='javascript:window.print()'   class='login oculto-impresion'> Print </a>" ;  // boton imprimir
	
	$query = "select * from groups where idgroup=".intval($_GET['lockergroup']);
	$result = conecta($query);
	$directorio="";
	$codigoQR="../qr/LockerIOT.png";
	if (mysqli_num_rows($result) >0 ){ 
	  $resultado=mysqli_fetch_array($result);
	  creaQR($resultado['refaccess']);
	  $imagenQR="qr/".$resultado['refaccess'].".png";
	  $textoParaCodigoQR="https://www.lockeriot.com/registration.php?refaccess=".$resultado['refaccess'];
	  
	  echo "<p>Group: ".$resultado['address']." | ".$resultado['address2']." | ".$resultado['place']." | ".$resultado['country']." </p>";
	  echo "<img id='qr".$resultado['idgroup']."'' src='".$imagenQR."' width='100%'  alt='QR Locker IOT registration' longdesc='QR Locker IOT registration' />";
	  echo "<p>URL :<strong> ".$textoParaCodigoQR." </strong></p>";
	}
	
}	else {
	// mostramos el menu de administrador
	// este menú es solamente para administrar el taquillero de Berlin
	echo "<h1>".espaleing("Men&uacute; de Administrador :","Verwaltungsmenü :","Administrator's menu:")."</h1>";

//echo "<p>QR de Grupo de Taquillas para registro de nuevos usuarios</p>";

echo "<a href='adminmenu.php?lockergroup=1'><p class='boton'>".espaleing("QR para registro de nuevos usuarios en: Siemens BERLIN ","QR für die Registrierung neuer Benutzer unter: Siemens BERLIN","QR for new user registration at: Siemens BERLIN")."</p></a>";
echo "<a href='admin_users.php?lockergroup=1' ><p class='boton'>".espaleing("Gestión de usuarios registrados","Verwaltung der registrierten Benutzer","Management of registered users")."</p></a>";


}


	


}
?>	 

	
	 
	</span>
	</article>

	</section>
	
	
	
	<?php  include ('piepagina.php');	?>
	
	</body> 
	
</html>