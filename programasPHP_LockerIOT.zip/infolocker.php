<?php
session_start();
require('general_func.php');

// este programa devuelve (si es un usuario autorizado) la información actual del locker
// también permite hacer una apertura del locker si se recibe el parámetro adicional open=1

// también permite hacer una liberacion del locker si se recibe el parámetro adicional free=1

// también permite ajustar el tiempo del locker para aviso alarma con el parametro adicional ma= minutos (1 a 20)

// si hay peticion de abrir,la hacemos primero  (si el status es 0, no se da orden de abrir pone si ya está abierta)

if(isset($_GET['id']) and intval($_GET['id']) >=0 and isset($_GET['open']) and intval($_GET['open']) >=0 and (isset($_SESSION['iduser']) and $_SESSION['iduser']>0 ) ){
   	$query = "UPDATE lockers set action=1 , timeaction=CURRENT_TIMESTAMP where status=0 and idlocker=".intval($_GET['id'])." and ( iduser=".$_SESSION['iduser']. " or iduser=0 )";
		
		// si es administrador, basta con el idlocker
		if(isset($_SESSION['generaladmin']) and $_SESSION['generaladmin']==1)
			$query = "UPDATE lockers set action=1 , timeaction=CURRENT_TIMESTAMP where status=0 and idlocker=".intval($_GET['id']);
		
									   
		$result = conecta($query);
		
		if($result){
			$txtEspanol="Se he enviado ORDEN de APERTURA (ocurrirá en unos 5 seg) ";
		    $txtAleman="Er&ouml;ffnungsauftrag wurde gesendet (erfolgt in ca. 5 Sek.)";
		    $txtIngles="OPENING ORDER has been sent (will occur in about 5 sec.) ";
			echo '<p class="avisoverde"> <span class="icon-checkmark"></span> '.espaleing($txtEspanol,$txtAleman,$txtIngles).' </p>'; 
			echo "<p class='boton2' onclick='gestionLocker()'> ".traduce("Actualizar")." </p>";
			// grabamos la accion (1 = abrir)
			$query="INSERT INTO orders ( iduser	, idlocker	, action) VALUES (".$_SESSION['iduser']. " , ".intval($_GET['id'])." , 1 )";
			$result = conecta($query);
			
		}	
		else{
			$txtEspanol="Ha ocurrido un Error ! No se ha podido enviar la orden de apertura. Por favor, int&eacute;ntelo de nuevo.";
		    $txtAleman="Es ist ein Fehler aufgetreten! Der Er&ouml;ffnungsauftrag konnte nicht gesendet werden. Bitte versuchen Sie es erneut.";
		    $txtIngles="An error has occurred ! The opening order could not be sent. Please try again. ";
			echo '<p class="aviso">'.espaleing($txtEspanol,$txtAleman,$txtIngles).' </p>';
		}
		  
	return;  // terminamos la actualización
}

// si hay peticion de liberar (RELEASE) free ,la hacemos primero
if(isset($_GET['id']) and intval($_GET['id']) >=0 and isset($_GET['free']) and intval($_GET['free']) >=0 and (isset($_SESSION['iduser']) and $_SESSION['iduser']>0 ) ){
   	$query = "UPDATE lockers set iduser=0 , action=0 , minsopentoalarm=5 , timeuser=CURRENT_TIMESTAMP where idlocker=".intval($_GET['id'])." and  iduser=".$_SESSION['iduser'];
		
		// si es administrador, basta con el idlocker
		if(isset($_SESSION['generaladmin']) and $_SESSION['generaladmin']==1)
			$query = "UPDATE lockers set status=0, iduser=0 , action=0 , minsopentoalarm=5,  timeuser=CURRENT_TIMESTAMP where idlocker=".intval($_GET['id']);
		
									   
		$result = conecta($query);
		
		if($result){
			$txtEspanol=" Se liberado la Taquilla";
		    $txtAleman=" Das Schließfach wurde freigegeben ";
		    $txtIngles="The Locker has been released. ";
			echo '<p class="avisoverde"> <span class="icon-checkmark"></span> '.espaleing($txtEspanol,$txtAleman,$txtIngles).'</p>'; 
			
			// grabamos la accion (2 = liberar)
			$query="INSERT INTO orders ( iduser	, idlocker	, action) VALUES (".$_SESSION['iduser']. " , ".intval($_GET['id'])." , 2 )";
			$result = conecta($query);
			
		}	
		else
			{
			$txtEspanol="Ha ocurrido un Error ! No se ha podido liberar el Locker. Por favor, int&eacute;ntelo de nuevo.";
		    $txtAleman="Es ist ein Fehler aufgetreten! Schließfach konnte nicht freigegeben werden. Bitte versuchen Sie es erneut.";
		    $txtIngles="An error has occurred ! Locker could not be released. Please try again. ";
			echo '<p class="aviso">'.espaleing($txtEspanol,$txtAleman,$txtIngles).' </p>';
			
		}
		  
	return;  // terminamos la actualización
}


// si hay peticion de hacer ajuste en tiempo de espera para email de alarma (parametro ma)
if(isset($_GET['id']) and intval($_GET['id']) >=0 and isset($_GET['ma']) and intval($_GET['ma']) >=1 and (isset($_SESSION['iduser']) and $_SESSION['iduser']>0 ) ){
   	$query = "UPDATE lockers set  minsopentoalarm=".intval($_GET['ma'])."  where idlocker=".intval($_GET['id'])." and  iduser=".$_SESSION['iduser'];
		
		// si es administrador, basta con el idlocker
		if(isset($_SESSION['generaladmin']) and $_SESSION['generaladmin']==1)
			$query = "UPDATE lockers set  minsopentoalarm=".intval($_GET['ma'])."  where idlocker=".intval($_GET['id']);
		
									   
		$result = conecta($query);
		
		if($result){
			$txtEspanol='<p class="avisoverde"> <span class="icon-checkmark"></span> Ajustado a '.intval($_GET['ma']).' min. el tiempo de apertura antes email de aviso. </p>';
		    $txtAleman='<p class="avisoverde"> <span class="icon-checkmark"></span> Angepasst auf   '.intval($_GET['ma']).' Minuten &Ouml;ffnungszeit vor Warn-E-Mail.</p>';
		    $txtIngles='<p class="avisoverde"> <span class="icon-checkmark"></span> Adjusted to '.intval($_GET['ma']).' minutes opening time before warning email. </p>';
			echo espaleing($txtEspanol,$txtAleman,$txtIngles); 
			
			// grabamos la accion (3 = ajuste tiempo espera alarma)
			$query="INSERT INTO orders ( iduser	, idlocker	, action) VALUES (".$_SESSION['iduser']. " , ".intval($_GET['id'])." , 3 )";
			$result = conecta($query);
			
		}	
		else{
			$txtEspanol='<p class="aviso">Ha ocurrido un Error ! No se ha podido cambiar el tiempo de la alarma por apertura. Por favor, inténtelo de nuevo.</p>';
		    $txtAleman='<p class="aviso"> Es ist ein Fehler aufgetreten! Es war nicht m&ouml;glich, die Weckzeit zu &auml;ndern. Bitte versuchen Sie es erneut.</p>';
		    $txtIngles='<p class="aviso"> An error has occurred ! It was not possible to change the opening alarm time. Please try again.</p>';
			echo espaleing($txtEspanol,$txtAleman,$txtIngles); 
		}
		  
	// no terminamos y continuamos con el estado del locker
}


// si trae POST id  buscamos la info del locker con igual idlocker

if(isset($_GET['id']) and intval($_GET['id']) >=0  and (isset($_SESSION['iduser']) and $_SESSION['iduser']>0 ) ){
	
		$query = "select * from lockers where idlocker=".intval($_GET['id'])." and ( iduser=".$_SESSION['iduser']. " or iduser=0 )";
		
		// si es administrador, basta con el idlocker
		if(isset($_SESSION['generaladmin']) and $_SESSION['generaladmin']==1)
			$query = "select * from lockers where idlocker=".intval($_GET['id']);
		
									   
		$result = conecta($query);
			if (mysqli_num_rows($result) >0 ){
				$fila = mysqli_fetch_assoc($result);
				
				if ($fila['status']==0){
					$txtEspanol="<div class='boton3t'> Taquilla CERRADA </div>  <div class='boton2' onclick='openLocker();'> Click para ABRIR </div> ";
					$txtAleman="<div class='boton3t'> Schlie&szlig;fach ist GESCHLOSSEN </div>  <div class='boton2' onclick='openLocker();'> Zum &Ouml;FFNEN klicken </div> ";
					$txtIngles="<div class='boton3t'> Locker is CLOSED </div>  <div class='boton2' onclick='openLocker();'> Click to OPEN </div> ";
					$estado= espaleing($txtEspanol,$txtAleman,$txtIngles);
				}else {
					$txtEspanol="<div class='boton4t'> Taquilla ABIERTA </div>";
					$txtAleman="<div class='boton4t'> Schlie&szlig;fach ist OFFEN </div>";
					$txtIngles="<div class='boton4t'> Locker is OPEN </div>";
					$estado= espaleing($txtEspanol,$txtAleman,$txtIngles);
	
				}
				
				echo  $estado ;
				if($fila['iduser']==$_SESSION['iduser'] or (isset($_SESSION['generaladmin']) and $_SESSION['generaladmin']==1)){
					$txtEspanol="<p id='desdeStatus'>En este estado desde : ".$fila['timestatus']."</p>";
					$txtAleman="<p id='desdeStatus'>In diesem Zustand seit : ".$fila['timestatus']."</p>";
					$txtIngles="<p id='desdeStatus'>In this state since : ".$fila['timestatus']."</p>";
					echo espaleing($txtEspanol,$txtAleman,$txtIngles); 
					if($fila['alarmsent']>0 and $fila['status']==1){
						$txtEspanol="<p>Enviado email de Aviso por duración apertura: ".$fila['timealarmsent']."</p>";
						$txtAleman="<p>E-Mail-Benachrichtigung &uuml:ber die Dauer der &Ouml;ffnung: ".$fila['timealarmsent']."</p>";
						$txtIngles="<p>Sent email notice for duration of opening: ".$fila['timealarmsent']."</p>";
						echo espaleing($txtEspanol,$txtAleman,$txtIngles); 
						}
					// gestion tiempo de apertura para alarma
						$txtEspanol="<p style='clear: both'>Ajustar tiempo para email de alerta:</p>";
						$txtAleman="<p style='clear: both'>Zeit f&uuml;r E-Mail-Warnungen anpassen:</p>";
						$txtIngles="<p style='clear: both'>Adjust time to alert email:</p>";
						echo espaleing($txtEspanol,$txtAleman,$txtIngles); 
					
					echo "<div class='slidecontainer'> 
						<input type='range' min='1' max='20' value='".$fila['minsopentoalarm']."' class='slider' name='rangomins' id='rangomins' oninput='setMinsToAlarm()'>
						</div>";
					echo "<p style='clear: both'>After <strong> <span id='txtrangomins'>".$fila['minsopentoalarm']."</span> </strong> ".traduce("Minutos con taquilla abierta.");
					echo "<span class='boton2'  style='float: none; width: auto;' onclick='timeToAlarmLocker()'>" .traduce("guardar"). " </span></p>";
						
					
					echo "<p class='boton2' onclick='gestionLocker()'> ".traduce("Actualizar")." </p>";
					if($fila['status']==1){
						$txtEspanol="<p>Por favor, cierre el Locker antes si desea liberarlo.</p>";
						$txtAleman="<p>Bitte schlie&szlig;en Sie das Schlie&szlig;fach zuerst, wenn Sie es freigeben m&ouml;chten.</p>";
						$txtIngles="<p>Please close the Locker first if you wish to release it.</p>";
						echo espaleing($txtEspanol,$txtAleman,$txtIngles); 
					}
						
				}
				
				
				if(isset($_SESSION['generaladmin']) and $_SESSION['generaladmin']==1){
					$txtEspanol="<p>Usuario actual asignado: ".$fila['iduser']." desde: ".$fila['timeuser']."</p>";
					$txtAleman="<p>Aktuell zugewiesener Benutzer: ".$fila['iduser']." Benutzer seit: ".$fila['timeuser']."</p>";
					$txtIngles="<p>Current user assigned: ".$fila['iduser']." user since : ".$fila['timeuser']."</p>";
					echo espaleing($txtEspanol,$txtAleman,$txtIngles); 
					
					// echo "<p>Acciones :</p>";  // posibles acciones para el administrador
				} 
				
					// si el locker no tiene usuario, asignamos el usuario a la taquilla y damos noticia al usuario 
					if($fila['iduser']==0){
						// UPDATE
						 $query2="UPDATE lockers SET status=0, action=0, iduser =" .$_SESSION['iduser']." , timeuser=CURRENT_TIMESTAMP WHERE idlocker=".intval($_GET['id']);
						 $result2 = conecta($query2);
						 if($result2){
							$txtEspanol='<p class="avisoverde"> <span class="icon-checkmark"></span> Taquilla asignada con éxito.</p>'; 
							$txtAleman='<p class="avisoverde"> <span class="icon-checkmark"></span>Schlie&szlig;fach erfolgreich zugewiesen.</p>';
							$txtIngles='<p class="avisoverde"> <span class="icon-checkmark"></span>Locker successfully assigned.</p>';
							echo espaleing($txtEspanol,$txtAleman,$txtIngles);
							  
						 } else {
							$txtEspanol='<p class="aviso">Ha ocurrido un Error ! La taquilla NO ha sido asignada.</p>'; 
							$txtAleman='<p class="aviso">Es ist ein Fehler aufgetreten! Das Schlie&szlig;fach ist NICHT zugewiesen worden.</p>'; 
							$txtIngles='<p class="aviso">An error has occurred ! The locker has NOT been assigned.</p>'; 
							echo espaleing($txtEspanol,$txtAleman,$txtIngles);
						 }
						  
					}
					
					// permitimos liberar si cerrada y no tiene ordenes de apertura pendientes
						if ($fila['status']==0 and $fila['action']==0){
						  // boton para opcion desasignar usuario
							$txtEspanol="<span class='boton4' onclick='releaseLocker();'> Clic para liberar la taquilla </span>"; 
							$txtAleman="<span class='boton4' onclick='releaseLocker();'> Klick zum Schlie&szlig;fach Release </span>";
							$txtIngles="<span class='boton4' onclick='releaseLocker();'> Click to Locker release </span>";
							echo espaleing($txtEspanol,$txtAleman,$txtIngles);
						 
						}
					
									
				
				
				
			} else {
				echo "ERROR: Access denied";
			}
		
}
else
   echo "Error";


?>