<?php
session_start();
require('general_func.php');
ponIdioma();
// Variables para datos de cabecera
$_SESSION['titulopagina']="Locker IOT Access";
$_SESSION['description']="Locker IOT Access ";
$_SESSION['keywords']="Locker IOT";




// Verificamos si procede de datos del propio formulario. Si es así se verifica usuario.
// variables para controlar el intento fallido
$_SESSION['intentofallido'] =0;


accesousuarios();

// ponemos cabeceras y menu
 	
	
	  include ('cabecera.php'); 
	  include ('menunavegacion.php'); 
	
 	
	echo "<section>";
	
	echo "<article><span class='no_selection'>";



// en funcion de resultados se compone la página
if(isset($_SESSION['estadousuario']) and $_SESSION['estadousuario']>=1 )
{

	// echo "<p>Your last access was : ". $_SESSION['ultacceso']. "</p>";
	
	
	// a usuarios con registro activo se les permite cambiar la clave
	
	 if(!isset($_POST['nuevaclave1']))
	 {}
	 else
	 {
	 if (strlen($_POST['nuevaclave1'])>3 and strlen($_POST['nuevaclave2'])>3)
	 {
	   if($_POST['nuevaclave1']==$_POST['nuevaclave2'])
	 {
	  // si se ha solicitado la cambio de claves se procede a ver si es posible
	     $queryclave="UPDATE users SET clave = SHA1('".$_POST['nuevaclave1']."') WHERE email='".$_SESSION['email']."'" ;
		 $resultclave = conecta($queryclave);
		 if($resultclave){
		  $txtEspanol="<li>Su clave de acceso ha sido modificada con &eacute;xito.</li>";
		  $txtAleman="<li>Ihr Passwort wurde erfolgreich ge&auml;ndert.</li>";
		  $txtIngles="<li>Your password was changed successfully.</li>";
		  echo espaleing($txtEspanol,$txtAleman,$txtIngles); 
		  //$_SESSION['permitecambioclave']=0;
		 }
		 else{
		  $txtEspanol="<li>Su clave de acceso <strong>NO se ha podido Modificar</strong>.</li>";
		  $txtAleman="<li>Ihr Passwort <strong> konnte NICHT ge&auml;ndert werden </strong>.</li>";
		  $txtIngles="<li>Your password <strong> could NOT be modified </strong></li>";
		  echo espaleing($txtEspanol,$txtAleman,$txtIngles); 
		 }
		  
	  
	 }
	 else{
		  $txtEspanol="<li>Las dos nuevas claves que ha introducido <strong>No Coinciden</strong>. No se ha cambiado su clave.</li>";
		  $txtAleman="<li>Die beiden neuen Schl&uuml;ssel, die Sie eingegeben haben, <strong> stimmen nicht &uuml;berein </strong>. Ihr Passwort wurde nicht ge&auml;ndert.</li>";
		  $txtIngles="<li>The two new keys you have entered <strong> Do Not Match </strong>. Your password has not been changed.</li>";
		  echo espaleing($txtEspanol,$txtAleman,$txtIngles); 
		 }
	   
	 }
	 }
	 
	 
	 if(isset($_GET['cambioclave']) and $_GET['cambioclave']==1)
	 {
	 
		  $txtEspanol="<p> Por favor introduzca su nueva clave de acceso:<br></p>";
		  $txtAleman="<p> Bitte geben Sie Ihr neues Passwort ein: <br> </p>";
		  $txtIngles="<p> Please enter your new password: <br> </p>";
		  echo espaleing($txtEspanol,$txtAleman,$txtIngles); 
	
	 echo '<div id="accesoform">'; 
	 echo '<form method="post" action="access.php">';
	 echo '<ul>';
		  $txtEspanol="Nueva clave de acceso ";
		  $txtAleman="neues Passwort ";
		  $txtIngles="New password ";
		   
     echo '<li>'.espaleing($txtEspanol,$txtAleman,$txtIngles).':<input type="password" name="nuevaclave1" size="10" /></li>';
	
		  $txtEspanol="Por favor, introduzca de nuevo su <br>nueva clave de acceso";
		  $txtAleman="Bitte geben Sie Ihr <br> Neues Passwort erneut ein:";
		  $txtIngles="Please re-enter your <br> New password:"; 
	 
     echo '<li>'.espaleing($txtEspanol,$txtAleman,$txtIngles).'<input type="password" name="nuevaclave2" size="10" /></li>';
	 
		  $txtEspanol="CAMBIAR";
		  $txtAleman="VER&Auml;NDERUNG";
		  $txtIngles="CHANGE"; 	 
     echo '<li><input class="botonacceso"  type="submit" value="'.espaleing($txtEspanol,$txtAleman,$txtIngles).'" /></li>';
	 echo '</ul>';
     echo '</form>';
	 echo '</div>';
	    
	 echo '</li>';
	 }
	 else
	 {
		 // gestión acciones de grupo  o de locker
		 // control con javascript. 
		 // Cargamos array con grupos disponibles y taquillas disponibles y propias  // Extendido si es administrador 
		echo "<script>";
		echo "var groups=[";
			$query = "select * from groups,groupsusers  where groups.idgroup=groupsusers.idgroup and groupsusers.iduser=".$_SESSION['iduser'];
			if($_SESSION['generaladmin']==1) // para administrador se selecciona todo
				$query = "select * from groups";
			$result = conecta($query);
			if (mysqli_num_rows($result) >0 )
			   { 
					$primera=1;
					$i=0;
					while ($fila = mysqli_fetch_assoc($result)) {
						
						if ($primera>0)
							$primera=0; 
						else
						   echo " , ";
					   
					   echo '[' .$i++. ',' .$fila['idgroup']. ' , '.
	                            '"'.utf8_encode($fila['address']). '" , '.
								'"'.utf8_encode($fila['address2']). '" , '.
								'"'.utf8_encode($fila['place']). '" , '.
								'"'.utf8_encode($fila['country']). '" , ';
								
						// ponemos las taquillas permitidas o todas si es un administrador
						if($_SESSION['generaladmin']==1)
							echo $fila['numlockers'];
						else
							echo $fila['numlockersallowed'];
								
					   echo		']';
								  
					}
			   }
		echo "];";// cerramos array de grupos
		echo "var lockers=[";
			$query = "select lockers.idgroup,idlocker,numingroup,lockers.iduser from lockers,groups,groupsusers  where groups.idgroup=groupsusers.idgroup and groups.idgroup=lockers.idgroup and groupsusers.iduser=".$_SESSION['iduser']." order by lockers.idgroup,numingroup ";
			if($_SESSION['generaladmin']==1) // para administrador se selecciona todos los lockers
				$query = "select * from lockers,groups where groups.idgroup=lockers.idgroup order by lockers.idgroup,numingroup ";
			$result = conecta($query);
			if (mysqli_num_rows($result) >0 )
			   { 
					$primera=1;
					$i=0;
					while ($fila = mysqli_fetch_assoc($result)) {
						
						if ($primera>0)
							$primera=0; 
						else
						   echo " , ";
					   
					   echo '[' .$i++. ',' .$fila['idgroup']. ' , '.$fila['idlocker']. ' , '.$fila['numingroup']. ' , ';
					   
					   if($fila['iduser']>0){
						   if($fila['iduser']==$_SESSION['iduser'])
							  echo "2"; // taquilla propia
						   else
							  echo "1"; // taquilla ocupada por otro usuario
					   } 
					   else
						   echo "0";  // taquilla vacia
	                            
						echo 	']';
								  
					}
			   }
		
		echo "];"; // cerramos array de lockers
		echo "</script>";
		
		echo "<div id=gestion></div>";  // en este div de hará toda la gestión de control del usuario
		include('access_script.php');  // funciones de inicio y gestión
					  
	 }
	
	

	
}
else
{
// Si ha intentado acceso fallido. damos mensaje
  if ($_SESSION['intentofallido']>0){
	  
			$txtEspanol="<p class='blanco'>La clave de acceso introducida no es correcta o el e-mail introducido no es correcto o no ha sido registrado<br> 
			Por favor, introduzca de nuevo su clave de acceso / e-mail o regístrese como usuario</p>";
			$txtAleman="<p class='blanco'> Das eingegebene Passwort ist nicht korrekt oder die eingegebene E-Mail ist nicht korrekt oder wurde nicht registriert <br>
			Bitte geben Sie Ihr Passwort / Ihre E-Mail erneut ein oder registrieren Sie sich als Benutzer</p>";
			$txtIngles="<p class='blanco'>The password entered is not correct or the e-mail entered is not correct or has not been registered <br>
			Please, re-enter your password / e-mail or register as a user</p>";
		  echo espaleing($txtEspanol,$txtAleman,$txtIngles); 

  }
// Crea formulario para la conexion

// SI SE HACEN CAMBIOS AQUI, cambiarlo tambien en el formulario de seccion.php

	echo "<h1>".traduce("Acceso usuarios")."</h1>";
	
		echo '<div id="accesoform">';

     echo '<form method="post" action="access.php">';
	 echo '<ul>';
     echo '<li> e-mail :<input type="e-mail" name="userid" size="30" /></li>';
     echo '<li>'.traduce("Clave").' :<input type="password" name="password" size="10" /></li>';
     echo '<li><input class="botonacceso" type="submit" value="'.traduce("Acceso").'" /></li>';
	 
		$txtEspanol="&iquest;Olvid&oacute; su contrase&ntilde;a?";
		$txtAleman="Passwort vergessen?";
		$txtIngles="Forgot Password?"; 
	  echo '<li>'.espaleing($txtEspanol,$txtAleman,$txtIngles).'<br> ';
	  
	    $txtEspanol="Haga clic aquí </a> para recuperar su contraseña";
		$txtAleman="Klicken Sie hier </a> um Ihr Passwort abzurufen";
		$txtIngles="Click here </a> to retrieve your password"; 
	  echo '<a href="recoverpassword.php" >'.espaleing($txtEspanol,$txtAleman,$txtIngles).'</li>';
	  
	    $txtEspanol="Nuevo usuario";
		$txtAleman="Neuer Benutzer";
		$txtIngles="New User";	
	 echo '<li><strong>'.espaleing($txtEspanol,$txtAleman,$txtIngles).'</strong>: <a href="registration.php">';
	 
		$txtEspanol="Haga clic aquí </a> para registrarse";
		$txtAleman="Klicken Sie hier</a> sich anmelden";
		$txtIngles="Click here </a> to sign up";
	 echo espaleing($txtEspanol,$txtAleman,$txtIngles).'</li>';
	 echo '</ul>';
     echo '</form>';

	echo '</div><!-- cierre div #accesoform -->';
	echo '<br>';
	
	    $txtEspanol="Las claves de acceso son personales e intransferibles.";
		$txtAleman="Der Zugangscode gilt als pers&ouml;nlich und nicht &uuml;bertragbar";
		$txtIngles="The access code is considered personal and non-transferable";
	echo '<div class="advertencia">'.traduce("ADVERTENCIA").':
		<br>
		<br> <strong>'.espaleing($txtEspanol,$txtAleman,$txtIngles).'</div>';

}
?>	 

	
	 
	</span>
	</article>

	</section>
	
	
	
	<?php  include ('piepagina.php');	?>
	
	</body> 
	
</html>